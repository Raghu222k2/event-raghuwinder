<?php
include_once "../header.php";
include '../db.php';

$sql = "SELECT venue, location, capacity, sq_ft, budget, image FROM venues WHERE status='Active'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discover Perfect Venues</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --text-dark: #1e293b;
            --text-light: #64748b;
            --bg-light: #f8fafc;
            --bg-white: #ffffff;
            --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius: 12px;
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--bg-light);
            color: var(--text-dark);
            line-height: 1.6;
        }

        .container {
            max-width: 1280px;
            margin: 0 auto;
            padding: 2rem;
        }

        .header {
            text-align: center;
            margin-bottom: 3rem;
        }

        .header h1 {
            font-size: 2.5rem;
            font-weight: 800;
            background: linear-gradient(to right, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .search-container {
            max-width: 600px;
            margin: 0 auto 3rem;
            position: relative;
        }

        .search-input {
            width: 100%;
            padding: 1rem 1.5rem;
            padding-left: 3rem;
            border: 1px solid #e2e8f0;
            border-radius: 50px;
            font-size: 1rem;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
        }

        .search-icon {
            position: absolute;
            left: 1.25rem;
            top: 50%;
            transform: translateY(-50%);
            color: var(--text-light);
        }

        .filter-container {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-bottom: 2.5rem;
        }

        .filter-btn {
            padding: 0.75rem 1.5rem;
            background-color: var(--bg-white);
            border: 1px solid #e2e8f0;
            border-radius: 50px;
            color: var(--text-light);
            font-weight: 500;
            cursor: pointer;
        }

        .venues-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 2rem;
        }

        .venue-card {
            background-color: var(--bg-white);
            border-radius: var(--radius);
            overflow: hidden;
            box-shadow: var(--shadow);
            padding: 1.5rem;
            text-align: center;
        }

        .venue-card img {
            width: 100%;
            border-radius: var(--radius);
            margin-bottom: 1rem;
        }

        .venue-title {
            font-size: 1.25rem;
            font-weight: 700;
            margin-bottom: 0.5rem;
            color: var(--text-dark);
        }

        .venue-location {
            font-size: 0.9rem;
            color: var(--text-light);
            margin-bottom: 1rem;
        }

        .venue-features {
            font-size: 0.9rem;
            color: var(--text-light);
            margin-bottom: 1rem;
        }

        .venue-features i {
            margin-right: 5px;
        }

        .venue-price {
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 0.5rem;
        }

        .venue-rating {
            display: flex;
            justify-content: center;
            align-items: center;
            color: var(--text-light);
            margin-bottom: 1rem;
        }

        .book-btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            background-color: var(--primary);
            color: white;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            text-align: center;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const searchInput = document.querySelector('.search-input');
            const venueCards = document.querySelectorAll('.venue-card');

            searchInput.addEventListener('input', function () {
                const searchTerm = searchInput.value.toLowerCase();

                venueCards.forEach(card => {
                    const title = card.querySelector('.venue-title').textContent.toLowerCase();
                    if (title.includes(searchTerm)) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Discover Perfect Venues</h1>
        </div>

        <div class="search-container">
            <i class="fas fa-search search-icon"></i>
            <input type="text" class="search-input" placeholder="Search for venues...">
        </div>

        <div class="venues-grid">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="venue-card">
                        <img src="../uploads/<?php echo $row['image']; ?>" alt="<?php echo $row['venue']; ?>">
                        <h3 class="venue-title"><?php echo $row['venue']; ?></h3>
                        <div class="venue-location"><?php echo $row['location']; ?></div>
                        <div class="venue-features">
                            <i class="fas fa-users"></i> <?php echo $row['capacity']; ?> guests | 
                            <i class="fas fa-expand"></i> <?php echo $row['sq_ft']; ?> sq ft
                        </div>
                        <div class="venue-price"><?php echo $row['budget']; ?> / day</div>
                        <a href="#" class="book-btn">Book Now</a>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No venues available at the moment.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
