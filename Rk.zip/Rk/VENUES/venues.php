<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php");
    exit();
}
?>
<?php include '../navbar.php'; ?>
<?php include '../db.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Clients Lists</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            function loadVenues() {
                $.ajax({
                    url: 'fetch_venues.php',
                    type: 'GET',
                    dataType: 'json',
                    success: function(data) {
                        let tbody = $('table tbody');
                        tbody.empty();
                        data.forEach((venue, index) => {
                            let statusClass = venue.status === 'Active' ? 'active' : '';
                            let newRow = `
                                <tr>
                                    <td>${index + 1}</td>
                                    <td>${venue.venue}</td>
                                    <td>${venue.budget}</td>
                                    <td>${venue.capacity}</td>
                                    <td>${venue.location}</td>
                                    <td>${venue.sq_ft}</td>
                                    <td><img src="../uploads/${venue.image}" alt="Venue Image" width="130px"></td>
                                    <td>
                                        <button class="action-btn edit-btn" data-id="${venue.id}">Edit</button>
                                        <button class="action-btn delete-btn" data-id="${venue.id}">Delete</button>
                                    </td>
                                    <td>
                                        <div class="status">
                                            <div class="status-toggle ${statusClass}" data-id="${venue.id}"></div>
                                        </div>
                                    </td>
                                </tr>
                            `;
                            tbody.append(newRow);
                        });
                    }
                });
            }

            loadVenues();

            $(document).on('click', '.status-toggle', function() {
                const toggle = $(this);
                const id = toggle.data('id');
                const newStatus = toggle.hasClass('active') ? 'Inactive' : 'Active';

                $.ajax({
                    url: 'toggle_status.php',
                    type: 'POST',
                    data: { id: id, status: newStatus },
                    success: function(response) {
                        toggle.toggleClass('active');
                    }
                });
            });

            $('#editEventForm').validate({
                rules: {
                    editEventVenue: {
                        required: true
                    },
                    editEventBudget: {
                        required: true,
                        number: true
                    },
                    editEventCapacity: {
                        required: true,
                        number: true
                    },
                    editEventLocation: {
                        required: true
                    },
                    editEventSqFt: {
                        required: true,
                        number: true
                    }
                },
                messages: {
                    editEventVenue: {
                        required: "Please enter the venue"
                    },
                    editEventBudget: {
                        required: "Please enter the budget",
                        number: "Please enter a valid budget"
                    },
                    editEventCapacity: {
                        required: "Please enter the capacity",
                        number: "Please enter a valid capacity"
                    },
                    editEventLocation: {
                        required: "Please enter the location"
                    },
                    editEventSqFt: {
                        required: "Please enter the square footage",
                        number: "Please enter a valid square footage"
                    }
                },
                submitHandler: function(form) {
                    const formData = new FormData(form);
                    formData.append('image', $('#editEventImage')[0].files[0]);
                    const eventId = $('#editEventId').val();
                    const eventVenue = $('#editEventVenue').val().trim();
                    const eventBudget = $('#editEventBudget').val().trim() + ' Rs';
                    const eventCapacity = $('#editEventCapacity').val().trim();
                    const eventLocation = $('#editEventLocation').val().trim();
                    const eventSqFt = $('#editEventSqFt').val().trim();

                    formData.append('id', eventId);
                    formData.append('venue', eventVenue);
                    formData.append('budget', eventBudget);
                    formData.append('capacity', eventCapacity);
                    formData.append('location', eventLocation);
                    formData.append('sq_ft', eventSqFt);

                    $.ajax({
                        url: 'update_venue.php',
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            loadVenues();
                            $('#editEventModal').modal('hide');
                        }
                    });
                }
            });

            $('#addEventForm').validate({
                rules: {
                    addEventVenue: {
                        required: true
                    },
                    addEventBudget: {
                        required: true,
                        number: true
                    },
                    addEventCapacity: {
                        required: true,
                        number: true
                    },
                    addEventLocation: {
                        required: true
                    },
                    addEventSqFt: {
                        required: true,
                        number: true
                    }
                },
                messages: {
                    addEventVenue: {
                        required: "Please enter the venue"
                    },
                    addEventBudget: {
                        required: "Please enter the budget",
                        number: "Please enter a valid budget"
                    },
                    addEventCapacity: {
                        required: "Please enter the capacity",
                        number: "Please enter a valid capacity"
                    },
                    addEventLocation: {
                        required: "Please enter the location"
                    },
                    addEventSqFt: {
                        required: "Please enter the square footage",
                        number: "Please enter a valid square footage"
                    }
                },
                submitHandler: function(form) {
                    const formData = new FormData(form);
                    formData.append('image', $('#addEventImage')[0].files[0]);
                    const eventVenue = $('#addEventVenue').val().trim();
                    const eventBudget = $('#addEventBudget').val().trim() + ' Rs';
                    const eventCapacity = $('#addEventCapacity').val().trim();
                    const eventLocation = $('#addEventLocation').val().trim();
                    const eventSqFt = $('#addEventSqFt').val().trim();

                    formData.append('venue', eventVenue);
                    formData.append('budget', eventBudget);
                    formData.append('capacity', eventCapacity);
                    formData.append('location', eventLocation);
                    formData.append('sq_ft', eventSqFt);

                    $.ajax({
                        url: 'add_venue.php',
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            loadVenues();
                            $('#addEventModal').modal('hide');
                        }
                    });
                }
            });

            $(document).on('click', '.edit-btn', function() {
                const row = $(this).closest('tr');
                const eventId = $(this).data('id');
                const eventVenue = row.find('td:eq(1)').text();
                const eventBudget = row.find('td:eq(2)').text().replace(' Rs', '');
                const eventCapacity = row.find('td:eq(3)').text();
                const eventLocation = row.find('td:eq(4)').text();
                const eventSqFt = row.find('td:eq(5)').text();

                $('#editEventId').val(eventId);
                $('#editEventVenue').val(eventVenue);
                $('#editEventBudget').val(eventBudget);
                $('#editEventCapacity').val(eventCapacity);
                $('#editEventLocation').val(eventLocation);
                $('#editEventSqFt').val(eventSqFt);

                $('#editEventModal').modal('show');
            });

            $(document).on('click', '.delete-btn', function() {
                const eventId = $(this).data('id');

                $.ajax({
                    url: 'delete_venue.php',
                    type: 'POST',
                    data: { id: eventId },
                    success: function(response) {
                        loadVenues();
                    }
                });
            });

            $('.add-user-btn').on('click', function() {
                $('#addEventModal').modal('show');
            });

            function updateSerialNumbers() {
                $('table tbody tr').each(function(index) {
                    $(this).find('td:eq(0)').text(index + 1);
                });
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">ADD VENUE</h1>
            <button class="add-user-btn">ADD NEW VENUE</button>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>Venue</th>
                        <th>Budget</th>
                        <th>Capacity</th>
                        <th>Location</th>
                        <th>Sq Ft</th>
                        <th>Image</th>
                        <th>Actions</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit Event Modal -->
    <div class="modal fade" id="editEventModal" tabindex="-1" aria-labelledby="editEventModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editEventModalLabel">Edit Venue</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editEventForm">
                        <input type="hidden" id="editEventId">
                        <div class="mb-3">
                            <label for="editEventVenue" class="form-label">Venue</label>
                            <input type="text" class="form-control" id="editEventVenue" name="editEventVenue" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventBudget" class="form-label">Budget</label>
                            <input type="number" class="form-control" id="editEventBudget" name="editEventBudget" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventCapacity" class="form-label">Capacity</label>
                            <input type="number" class="form-control" id="editEventCapacity" name="editEventCapacity" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventLocation" class="form-label">Location</label>
                            <input type="text" class="form-control" id="editEventLocation" name="editEventLocation" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventSqFt" class="form-label">Sq Ft</label>
                            <input type="number" class="form-control" id="editEventSqFt" name="editEventSqFt" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventImage" class="form-label">Image</label>
                            <input type="file" class="form-control" id="editEventImage" name="editEventImage" accept="image/*">
                        </div>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Event Modal -->
    <div class="modal fade" id="addEventModal" tabindex="-1" aria-labelledby="addEventModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addEventModalLabel">Add Venue</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addEventForm">
                        <div class="mb-3">
                            <label for="addEventVenue" class="form-label">Venue</label>
                            <input type="text" class="form-control" id="addEventVenue" name="addEventVenue" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventBudget" class="form-label">Budget</label>
                            <input type="number" class="form-control" id="addEventBudget" name="addEventBudget" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventCapacity" class="form-label">Capacity</label>
                            <input type="number" class="form-control" id="addEventCapacity" name="addEventCapacity" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventLocation" class="form-label">Location</label>
                            <input type="text" class="form-control" id="addEventLocation" name="addEventLocation" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventSqFt" class="form-label">Sq Ft</label>
                            <input type="number" class="form-control" id="addEventSqFt" name="addEventSqFt" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventImage" class="form-label">Image</label>
                            <input type="file" class="form-control" id="addEventImage" name="addEventImage" accept="image/*" required>
                        </div>
                        <button type="submit" class="btn btn-primary">Add Venue</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>