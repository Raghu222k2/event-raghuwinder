<?php
include '../db.php';

$id = $_POST['id'];
$status = $_POST['status'];

$sql = "UPDATE venues SET status='$status' WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    echo "Status updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
