<?php
include '../db.php';

$venue = $_POST['venue'];
$budget = $_POST['budget'];
$capacity = $_POST['capacity'];
$sq_ft = $_POST['sq_ft'];
$location = $_POST['location'];
$image = $_FILES['image']['name'];
$target = "../uploads/" . basename($image);

if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
    $sql = "INSERT INTO venues (venue, budget, capacity, sq_ft, location, image) VALUES ('$venue', '$budget', '$capacity', '$sq_ft', '$location', '$image')";

    if ($conn->query($sql) === TRUE) {
        echo "New venue added successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Failed to upload image";
}

$conn->close();
?>
