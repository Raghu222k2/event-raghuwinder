<?php
include '../db.php';

$sql = "SELECT id, venue, budget, capacity, sq_ft, location, image, status FROM venues";
$result = $conn->query($sql);

$venues = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $venues[] = $row;
    }
}

echo json_encode($venues);

$conn->close();
?>
