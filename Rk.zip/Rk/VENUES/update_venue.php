<?php
include '../db.php';

$id = $_POST['id'];
$venue = $_POST['venue'];
$budget = $_POST['budget'];
$capacity = $_POST['capacity'];
$sq_ft = $_POST['sq_ft'];
$location = $_POST['location'];
$image = $_FILES['image']['name'];

if ($image) {
    $target = "../uploads/" . basename($image);
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $sql = "UPDATE venues SET venue='$venue', budget='$budget', capacity='$capacity', sq_ft='$sq_ft', location='$location', image='$image' WHERE id=$id";
    } else {
        echo "Failed to upload image";
    }
} else {
    $sql = "UPDATE venues SET venue='$venue', budget='$budget', capacity='$capacity', sq_ft='$sq_ft', location='$location' WHERE id=$id";
}

if ($conn->query($sql) === TRUE) {
    echo "Venue updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
