<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT id, event_name, description, experience, email, price, image, status FROM event_manager";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['event_name']}</td>
                <td>{$row['description']}</td>
                <td>{$row['experience']}</td>
                <td>{$row['email']}</td>
                <td>&#8377; {$row['price']}</td> <!-- Updated to rupee symbol -->
                <td><img src='{$row['image']}' alt='Event Image' height='105px' width='180px'></td>
                <td>
                    <button class='action-btn edit-btn'>Edit</button>
                    <button class='action-btn delete-btn'>Delete</button>
                </td>
                <td>
                    <div class='status'>
                        <div class='status-toggle " . ($row['status'] == 'active' ? 'active' : '') . "'></div>
                    </div>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='9'>No events found</td></tr>";
}

$conn->close();
?>
