<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];
    $event_name = $_POST['event_name'];
    $description = $_POST['description'];
    $experience = $_POST['experience'];
    $email = $_POST['email'];
    $price = $_POST['price'];
    $image = $_FILES['image']['name'];
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($image);

    if (!empty($image) && move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        $stmt = $conn->prepare("UPDATE event_manager SET event_name = ?, description = ?, experience = ?, email = ?, price = ?, image = ? WHERE id = ?");
        $stmt->bind_param("ssisssi", $event_name, $description, $experience, $email, $price, $target_file, $id);
    } else {
        $stmt = $conn->prepare("UPDATE event_manager SET event_name = ?, description = ?, experience = ?, email = ?, price = ? WHERE id = ?");
        $stmt->bind_param("ssissi", $event_name, $description, $experience, $email, $price, $id);
    }

    if ($stmt->execute()) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    $stmt->close();
} else {
    echo "Invalid request.";
}

$conn->close();
?>
