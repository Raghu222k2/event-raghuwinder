<?php
include_once "../header.php";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch planners from the database
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$sql = "SELECT event_name, description, experience, email, price, image FROM event_manager WHERE status = 'active'";
if (!empty($search)) {
    $sql .= " AND (event_name LIKE '%$search%' OR description LIKE '%$search%' OR email LIKE '%$search%')";
}
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Event Planners</title>
    <link rel="stylesheet" href="../style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
    --primary: #8b5cf6;
    --primary-dark: #7c3aed;
    --secondary: #ec4899;
    --text-dark: #1e293b;
    --text-light: #64748b;
    --text-lighter: #94a3b8;
    --bg-light: #f8fafc;
    --bg-white: #ffffff;
    --shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
    --radius: 12px;
    --transition: all 0.3s ease;
}

* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background-color: var(--bg-light);
    color: var(--text-dark);
    line-height: 1.6;
}

/* Container */
.container {
    max-width: 1280px;
    margin: 0 auto;
    padding: 2rem;
}

/* Header Section */
.header {
    text-align: center;
    margin-bottom: 3rem;
}

.header h1 {
    font-size: 2.5rem;
    font-weight: 800;
    margin-bottom: 1rem;
    background: linear-gradient(to right, var(--primary), var(--secondary));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
}

.header p {
    font-size: 1.1rem;
    color: var(--text-light);
    max-width: 700px;
    margin: 0 auto;
}
/* Search Bar */
.search-container {
    max-width: 600px;
    margin: 0 auto 3rem;
    position: relative;
}

.search-input {
    width: 100%;
    padding: 1rem 1.5rem;
    padding-left: 3rem;
    border: 1px solid #e2e8f0;
    border-radius: 50px;
    font-size: 1rem;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    transition: var(--transition);
}

.search-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2);
}

.search-icon {
    position: absolute;
    left: 1.25rem;
    top: 50%;
    transform: translateY(-50%);
    color: var(--text-lighter);
}

/* Planners Grid */
.planners-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 2rem;
}

/* Planner Card */
.planner-card {
    background-color: var(--bg-white);
    border-radius: var(--radius);
    overflow: hidden;
    box-shadow: var(--shadow);
    transition: var(--transition);
    position: relative;
}

.planner-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
}

.planner-header {
    position: relative;
    height: 120px;
    background: linear-gradient(to right, var(--primary), var(--secondary));
}

.planner-badge {
    position: absolute;
    top: 1rem;
    left: 1rem;
    background-color: rgba(255, 255, 255, 0.9);
    color: var(--primary);
    padding: 0.35rem 0.75rem;
    border-radius: 50px;
    font-size: 0.75rem;
    font-weight: 600;
    z-index: 1;
}

.planner-save {
    position: absolute;
    top: 1rem;
    right: 1rem;
    background-color: rgba(255, 255, 255, 0.8);
    width: 36px;
    height: 36px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 1;
    transition: var(--transition);
}

.planner-save:hover {
    background-color: white;
}

.planner-save i {
    color: var(--secondary);
    font-size: 1.1rem;
}

.planner-image {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 4px solid white;
    position: absolute;
    bottom: -60px;
    left: 50%;
    transform: translateX(-50%);
    overflow: hidden;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.planner-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.planner-content {
    padding: 4rem 1.5rem 1.5rem;
    text-align: center;
}

.planner-name {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 0.25rem;
    color: var(--text-dark);
}

.planner-title {
    color: var(--primary);
    font-weight: 600;
    font-size: 1rem;
    margin-bottom: 1rem;
}

.planner-rating {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 1rem;
}

.planner-rating i {
    color: #f59e0b;
    font-size: 0.9rem;
    margin-right: 0.15rem;
}

.planner-rating span {
    font-weight: 600;
    margin-left: 0.5rem;
    color: var(--text-dark);
}

.planner-description {
    color: var(--text-light);
    margin-bottom: 1.5rem;
    font-size: 0.95rem;
}

.planner-details {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
    margin-bottom: 1.5rem;
}

.detail-item {
    display: flex;
    align-items: center;
    font-size: 0.95rem;
    color: var(--text-light);
}

.detail-item i {
    width: 20px;
    margin-right: 0.75rem;
    color: var(--primary);
}

.planner-price {
    font-size: 1.25rem;
    font-weight: 700;
    color: var(--text-dark);
    margin-bottom: 1.5rem;
}

.planner-price span {
    font-size: 0.9rem;
    font-weight: 400;
    color: var (--text-light);
}

.contact-btn {
    display: inline-block;
    width: 100%;
    padding: 0.875rem 1.5rem;
    background-color: var(--primary);
    color: white;
    border-radius: 50px;
    font-weight: 600;
    text-decoration: none;
    transition: var(--transition);
    text-align: center;
    border: none;
    cursor: pointer;
}

.contact-btn:hover {
    background-color: var(--primary-dark);
}

/* Load More Button */
.load-more {
    display: block;
    margin: 3rem auto 0;
    padding: 0.875rem 2rem;
    background-color: transparent;
    border: 2px solid var(--primary);
    color: var(--primary);
    font-weight: 600;
    border-radius: 50px;
    cursor: pointer;
    transition: var(--transition);
}

.load-more:hover {
    background-color: var(--primary);
    color: white;
}

/* Responsive Design */
@media (max-width: 768px) {
    .planners-grid {
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    }
    
    .header h1 {
        font-size: 2rem;
    }
    
    .container {
        padding: 1.5rem;
    }
}

@media (max-width: 480px) {
    .planners-grid {
        grid-template-columns: 1fr;
    }
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    justify-content: center;
    align-items: center;
}

.modal-content {
    background-color: white;
    border-radius: var(--radius);
    width: 90%;
    max-width: 500px;
    padding: 2rem;
    position: relative;
    animation: modalFadeIn 0.3s ease;
}

@keyframes modalFadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.close-modal {
    position: absolute;
    top: 1rem;
    right: 1rem;
    font-size: 1.5rem;
    color: var(--text-light);
    cursor: pointer;
    transition: var(--transition);
}

.close-modal:hover {
    color: var(--text-dark);
}

.modal-title {
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 1.5rem;
    color: var(--primary);
}

.form-group {
    margin-bottom: 1.25rem;
}

.form-label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: var(--text-dark);
}

.form-input {
    width: 100%;
    padding: 0.75rem 1rem;
    border: 1px solid #e2e8f0;
    border-radius: 0.375rem;
    font-size: 1rem;
    transition: var(--transition);
}

.form-input:focus {
    outline: none;
    border-color: var(--primary);
    box-shadow: 0 0 0 3px rgba(139, 92, 246, 0.2);
}

.form-textarea {
    min-height: 120px;
    resize: vertical;
}

.submit-btn {
    width: 100%;
    padding: 0.875rem 1.5rem;
    background-color: var(--primary);
    color: white;
    border: none;
    border-radius: 50px;
    font-weight: 600;
    cursor: pointer;
    transition: var(--transition);
}

.submit-btn:hover {
    background-color: var(--primary-dark);
}
        .header {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            height: 100px; /* Adjust height as needed */
        }

        .header h1 {
            margin: 0;
            font-size: 2.5rem; /* Adjust font size as needed */
        }

        .header p {
            margin-top: 10px;
            font-size: 1.2rem; /* Adjust font size as needed */
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header Section -->
        <div class="header">
            <h1>Expert Event Planners</h1>
            <p>Find the perfect event planner to make your special occasion memorable, stress-free, and exactly as you've always imagined.</p>
        </div>

        <!-- Search Bar -->
        <form class="search-container" method="GET" action="">
            <i class="fas fa-search search-icon"></i>
            <input type="text" name="search" class="search-input" placeholder="Search by name, specialty, or location..." value="<?php echo htmlspecialchars($search); ?>">
        </form>

        <!-- Planners Grid -->
        <div class="planners-grid">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="planner-card">
                        <div class="planner-header">
                            <div class="planner-badge">Top Rated</div>
                            <div class="planner-image">
                                <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="Planner Image">
                            </div>
                        </div>
                        <div class="planner-content">
                            <h3 class="planner-name"><?php echo htmlspecialchars($row['event_name']); ?></h3>
                            <p class="planner-title">Professional Event Planner</p>
                            
                            <div class="planner-rating">
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <i class="fas fa-star"></i>
                                <span>5.0</span>
                            </div>
                            
                            <p class="planner-description">
                                <?php echo htmlspecialchars($row['description']); ?>
                            </p>
                            
                            <div class="planner-details">
                                <div class="detail-item">
                                    <i class="fas fa-briefcase"></i>
                                    <span><?php echo htmlspecialchars($row['experience']); ?> years experience</span>
                                </div>
                                <div class="detail-item">
                                    <i class="fas fa-envelope"></i>
                                    <span><?php echo htmlspecialchars($row['email']); ?></span>
                                </div>
                            </div>
                            
                            <div class="planner-price">
                                &#8377;<?php echo htmlspecialchars($row['price']); ?> <span>starting price</span>
                            </div>
                            
                            <button class="contact-btn" data-planner="<?php echo htmlspecialchars($row['event_name']); ?>">Contact Now</button>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No planners found.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Contact modal functionality
            const contactButtons = document.querySelectorAll('.contact-btn');
            contactButtons.forEach(button => {
                button.addEventListener('click', function() {
                    alert(`Contacting ${this.getAttribute('data-planner')}`);
                });
            });
        });
    </script>
</body>
</html>
<?php $conn->close(); ?>