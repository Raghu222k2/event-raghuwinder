<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php");
    exit();
}
?>
<?php include '../navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style.css">
    <title>Event Manager</title>
    <style>
        .btn-primary {
            background-color: #4299e1; /* Updated color */
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #3182ce; /* Slightly darker shade for hover */
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            // Fetch and display events
            function fetchEvents() {
                $.ajax({
                    url: 'fetch_events.php',
                    type: 'GET',
                    success: function(response) {
                        $('table tbody').html(response);
                    }
                });
            }
            fetchEvents();

            // Add Event Form Validation
            $('#addEventForm').validate({
                rules: {
                    event_name: "required",
                    description: "required",
                    experience: {
                        required: true,
                        number: true,
                        min: 0
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    price: {
                        required: true,
                        number: true,
                        min: 0
                    },
                    image: "required"
                },
                messages: {
                    event_name: "Please enter the event name",
                    description: "Please enter a description",
                    experience: {
                        required: "Please enter the experience",
                        number: "Experience must be a number",
                        min: "Experience cannot be negative"
                    },
                    email: {
                        required: "Please enter an email",
                        email: "Please enter a valid email"
                    },
                    price: {
                        required: "Please enter the price",
                        number: "Price must be a number",
                        min: "Price cannot be negative"
                    },
                    image: "Please upload an image"
                },
                submitHandler: function(form) {
                    const formData = new FormData(form);
                    $.ajax({
                        url: 'add_event.php',
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            fetchEvents();
                            $('#addEventModal').modal('hide');
                            $('#addEventForm')[0].reset();
                        }
                    });
                }
            });

            // Edit Event Form Validation
            $('#editEventForm').validate({
                rules: {
                    event_name: "required",
                    description: "required",
                    experience: {
                        required: true,
                        number: true,
                        min: 0
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    price: {
                        required: true,
                        number: true,
                        min: 0
                    }
                },
                messages: {
                    event_name: "Please enter the event name",
                    description: "Please enter a description",
                    experience: {
                        required: "Please enter the experience",
                        number: "Experience must be a number",
                        min: "Experience cannot be negative"
                    },
                    email: {
                        required: "Please enter an email",
                        email: "Please enter a valid email"
                    },
                    price: {
                        required: "Please enter the price",
                        number: "Price must be a number",
                        min: "Price cannot be negative"
                    }
                },
                submitHandler: function(form) {
                    const formData = new FormData(form);
                    $.ajax({
                        url: 'update_event.php',
                        type: 'POST',
                        data: formData,
                        processData: false,
                        contentType: false,
                        success: function(response) {
                            fetchEvents();
                            $('#editEventModal').modal('hide');
                        }
                    });
                }
            });

            // Edit Event
            $(document).on('click', '.edit-btn', function() {
                const row = $(this).closest('tr');
                $('#editEventId').val(row.find('td:eq(0)').text().trim());
                $('#editEventName').val(row.find('td:eq(1)').text().trim());
                $('#editEventDescription').val(row.find('td:eq(2)').text().trim());
                $('#editEventExperience').val(row.find('td:eq(3)').text().trim());
                $('#editEventEmail').val(row.find('td:eq(4)').text().trim());
                $('#editEventPrice').val(row.find('td:eq(5)').text().trim());
                $('#editEventModal').modal('show'); // Ensure this line triggers the modal
            });

            // Delete Event
            $(document).on('click', '.delete-btn', function() {
                if (confirm('Are you sure you want to delete this event?')) {
                    const eventId = $(this).closest('tr').find('td:eq(0)').text();
                    $.ajax({
                        url: 'delete_event.php',
                        type: 'POST',
                        data: { id: eventId },
                        success: function(response) {
                            fetchEvents();
                        }
                    });
                }
            });

            // Toggle Status
            $(document).on('click', '.status-toggle', function() {
                const row = $(this).closest('tr');
                const eventId = row.find('td:eq(0)').text();
                const newStatus = $(this).hasClass('active') ? 'inactive' : 'active';
                $.ajax({
                    url: 'update_status.php',
                    type: 'POST',
                    data: { id: eventId, status: newStatus },
                    success: function(response) {
                        fetchEvents();
                    }
                });
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">Event Manager</h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEventModal">Add Planner</button>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Experience</th>
                        <th>Email</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Actions</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Events will be loaded here -->
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Event Modal -->
    <div class="modal fade" id="addEventModal" tabindex="-1" aria-labelledby="addEventModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="addEventForm" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addEventModalLabel">Add Event</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="addEventName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="addEventName" name="event_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventDescription" class="form-label">Description</label>
                            <textarea class="form-control" id="addEventDescription" name="description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="addEventExperience" class="form-label">Experience</label>
                            <input type="number" class="form-control" id="addEventExperience" name="experience" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="addEventEmail" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventPrice" class="form-label">Price</label>
                            <input type="number" class="form-control" id="addEventPrice" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventImage" class="form-label">Image</label>
                            <input type="file" class="form-control" id="addEventImage" name="image" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add Event</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Event Modal -->
    <div class="modal fade" id="editEventModal" tabindex="-1" aria-labelledby="editEventModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editEventForm" enctype="multipart/form-data">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editEventModalLabel">Edit Event</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="editEventId" name="id">
                        <div class="mb-3">
                            <label for="editEventName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="editEventName" name="event_name" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventDescription" class="form-label">Description</label>
                            <textarea class="form-control" id="editEventDescription" name="description" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="editEventExperience" class="form-label">Experience</label>
                            <input type="number" class="form-control" id="editEventExperience" name="experience" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="editEventEmail" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventPrice" class="form-label">Price</label>
                            <input type="number" class="form-control" id="editEventPrice" name="price" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventImage" class="form-label">Image</label>
                            <input type="file" class="form-control" id="editEventImage" name="image">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>