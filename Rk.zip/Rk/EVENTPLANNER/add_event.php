<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $event_name = $_POST['event_name'] ?? '';
    $description = $_POST['description'] ?? '';
    $experience = $_POST['experience'] ?? '';
    $email = $_POST['email'] ?? '';
    $price = $_POST['price'] ?? '';
    $image = $_FILES['image']['name'] ?? '';

    // Validate required fields
    if (empty($event_name) || empty($description) || empty($experience) || empty($email) || empty($price) || empty($image)) {
        die("All fields are required.");
    }

    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($image);

    // Ensure uploads directory exists
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }

    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        $stmt = $conn->prepare("INSERT INTO event_manager (event_name, description, experience, email, price, image, status) VALUES (?, ?, ?, ?, ?, ?, 'active')");
        $stmt->bind_param("ssisss", $event_name, $description, $experience, $email, $price, $target_file);

        if ($stmt->execute()) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error uploading image.";
    }
} else {
    echo "Invalid request.";
}

$conn->close();
?>
