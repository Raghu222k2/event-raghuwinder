<?php
session_start();
include_once "db.php";

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];

    // Update the user's status to "Inactive"
    $sql = "UPDATE users SET status = 'Inactive' WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->close();
}

session_unset(); // Unset all session variables
session_destroy(); // Destroy the session

// Prevent back navigation after logout
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// Redirect to the login page using an absolute path
header("Location: /Rk/login.php");
exit();
?>
