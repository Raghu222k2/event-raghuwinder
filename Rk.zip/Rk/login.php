<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: dashboard.php"); // Redirect to dashboard if already logged in
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #4a90e2 0%, #003366 100%);
        }

        .login-container {
            width: 100%;
            max-width: 400px;
            padding: 2rem;
            text-align: center;
        }

        .avatar {
            width: 80px;
            height: 80px;
            background-color: #003366;
            border-radius: 50%;
            margin: 0 auto 1rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .avatar svg {
            width: 40px;
            height: 40px;
            fill: #ffffff;
        }

        .title {
            color: white;
            font-size: 1.2rem;
            letter-spacing: 2px;
            margin-bottom: 2rem;
            font-weight: 300;
        }

        .input-group {
            position: relative;
            margin-bottom: 1.5rem;
        }

        .input-group input {
            width: 100%;
            padding: 10px 0;
            font-size: 16px;
            color: white;
            border: none;
            border-bottom: 1px solid rgba(255, 255, 255, 0.3);
            outline: none;
            background: transparent;
            padding-left: 30px;
        }

        .input-group input::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }

        .input-group svg {
            position: absolute;
            left: 0;
            top: 50%;
            transform: translateY(-50%);
            width: 20px;
            height: 20px;
            fill: rgba(255, 255, 255, 0.6);
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
            color: rgba(255, 255, 255, 0.8);
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 14px;
        }

        .remember-me input[type="checkbox"] {
            accent-color: #003366;
        }

        .forgot-password {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            font-size: 14px;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }

        .login-btn {
            width: 100%;
            padding: 12px;
            background: #003366;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background 0.3s ease;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .login-btn:hover {
            background: #004080;
        }

        input:focus {
            border-bottom-color: white;
        }

        input:invalid {
            border-bottom-color: #ff4444;
        }

        .error {
            color: #ff4444;
            font-size: 14px;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            const predefinedUserID = "Raghu";
            const predefinedPassword = "Raghu11";

            $('form').on('submit', function(event) {
                event.preventDefault();
                let isValid = true;
                $('.error').remove();

                const userID = $('#userid').val().trim();
                const password = $('#password').val().trim();

                if (userID === '') {
                    isValid = false;
                    $('#userid').after('<div class="error">User ID is required</div>');
                }

                if (password === '') {
                    isValid = false;
                    $('#password').after('<div class="error">Password is required</div>');
                } else if (password.length < 6) {
                    isValid = false;
                    $('#password').after('<div class="error">Password must be at least 6 characters</div>');
                }

                if (isValid) {
                    if (userID === predefinedUserID && password === predefinedPassword) {
                        // Set session variables via AJAX
                        $.post('set_session.php', { user_id: userID }, function(response) {
                            if (response.success) {
                                window.location.href = 'dashboard.php';
                            } else {
                                $('#password').after('<div class="error">Failed to log in. Please try again.</div>');
                            }
                        }, 'json');
                    } else {
                        $('#password').after('<div class="error">Invalid User ID or Password</div>');
                    }
                }
            });
        });
    </script>
</head>
<body>
    <div class="login-container">
        <div class="avatar">
            <svg viewBox="0 0 24 24">
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
            </svg>
        </div>
        <h1 class="title">ADMIN LOGIN</h1>
        <form>
            <div class="input-group">
                <svg viewBox="0 0 24 24">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
                <input type="text" id="userid" placeholder="User ID" required>
            </div>
            <div class="input-group">
                <svg viewBox="0 0 24 24">
                    <path d="M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z"/>
                </svg>
                <input type="password" id="password" placeholder="Password" required minlength="6">
            </div>
            <div class="remember-forgot">
                <label class="remember-me">
                    <input type="checkbox" id="remember">
                    Remember me
                </label>
                <a href="#" class="forgot-password">Forgot Password?</a>
            </div>
            <button type="submit" class="login-btn">Login</button>
        </form>
    </div>
</body>
</html>