<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php");
    exit();
}

include "../db.php";
include "../navbar.php";

$message = ""; // Initialize message variable

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hero_title = $conn->real_escape_string($_POST['hero_title']);
    $hero_description = $conn->real_escape_string($_POST['hero_description']);
    $story_title = $conn->real_escape_string($_POST['story_title']);
    $story_description = $conn->real_escape_string($_POST['story_description']);
    
    // Handle image upload
    $story_image = $_POST['existing_image'];
    if (!empty($_FILES['story_image']['name'])) {
        $target_dir = "../uploads/";
        $story_image = basename($_FILES['story_image']['name']);
        move_uploaded_file($_FILES['story_image']['tmp_name'], $target_dir . $story_image);
    }

    // Update the about_us table
    $sql = "UPDATE about_us SET 
        hero_title = '$hero_title', 
        hero_description = '$hero_description', 
        story_title = '$story_title', 
        story_description = '$story_description', 
        story_image = '$story_image' 
        WHERE id = 1";
    $conn->query($sql);
    $message = "Content updated successfully!";
}

// Fetch current content
$sql = "SELECT * FROM about_us LIMIT 1";
$result = $conn->query($sql);
$about = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin - Edit About Us</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }
        input[type="text"], textarea, input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        textarea {
            resize: vertical;
            height: 100px;
        }
        button {
            display: block;
            width: 100%;
            padding: 10px;
            background: #6a11cb;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 18px;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        button:hover {
            background: #2575fc;
        }
        img {
            display: block;
            max-width: 100%;
            margin: 10px 0;
            border-radius: 8px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .message {
            text-align: center;
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border: 1px solid #c3e6cb;
            border-radius: 4px;
            margin-bottom: 20px;
            display: none;
        }
    </style>
    <script>
        // Hide the message after 3 seconds
        document.addEventListener("DOMContentLoaded", function () {
            const message = document.querySelector(".message");
            if (message) {
                message.style.display = "block";
                setTimeout(() => {
                    message.style.display = "none";
                }, 3000);
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        <h1>Edit About Us</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>Hero Title:</label>
                <input type="text" name="hero_title" value="<?php echo htmlspecialchars($about['hero_title']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Hero Description:</label>
                <textarea name="hero_description" required><?php echo htmlspecialchars($about['hero_description']); ?></textarea>
            </div>
            
            <div class="form-group">
                <label>Story Title:</label>
                <input type="text" name="story_title" value="<?php echo htmlspecialchars($about['story_title']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Story Description:</label>
                <textarea name="story_description" required><?php echo htmlspecialchars($about['story_description']); ?></textarea>
            </div>
            
            <div class="form-group">
                <label>Story Image:</label>
                <input type="file" name="story_image">
                <input type="hidden" name="existing_image" value="<?php echo htmlspecialchars($about['story_image']); ?>">
                <img src="../uploads/<?php echo htmlspecialchars($about['story_image']); ?>" alt="Current Image">
            </div>
            
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
