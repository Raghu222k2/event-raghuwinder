<?php 
include_once "../header.php";
include "../db.php"; 

// Fetch content from about_us table
$sql = "SELECT * FROM about_us LIMIT 1";
$result = $conn->query($sql);
$about = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Event Venues</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
            color: white;
            padding: 100px 0 50px;
            text-align: center;
            position: relative;
            overflow: hidden;
        }
        
        .hero::before {
            /* margin: 10rem; */
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            /* background: url('https://placehold.co/1200x400?text=') no-repeat center center; */
            opacity: 0.1;
            z-index: 0;
        }
        
        .hero-content {
            position: relative;
            z-index: 1;
        }
        
        .hero h1 {
            font-size: 3.5rem;
            margin-bottom: 20px;
            font-weight: 700;
        }
        
        .hero p {
            font-size: 1.2rem;
            max-width: 800px;
            margin: 0 auto 30px;
        }
        
        /* Story Section */
        .story {
            padding: 80px 0;
            background-color: white;
        }
        
        .story-container {
            display: flex;
            align-items: center;
            gap: 50px;
        }
        
        .story-image {
            flex: 1;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .story-image img {
            width: 100%;
            height: auto;
            display: block;
        }
        
        .story-content {
            flex: 1;
        }
        
        .story h2 {
            font-size: 2.5rem;
            margin-bottom: 20px;
            color: #333;
            position: relative;
            padding-bottom: 15px;
        }
        
        .story h2::after {
            content: "";
            position: absolute;
            bottom: 0;
            left: 0;
            width: 80px;
            height: 4px;
            background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
        }
        
        .story p {
            margin-bottom: 20px;
            font-size: 1.1rem;
        }
        
        /* Responsive Design */
        @media (max-width: 900px) {
            .story-container {
                flex-direction: column;
            }
            
            .hero h1 {
                font-size: 2.5rem;
            }
            
            .story h2 {
                font-size: 2rem;
            }
        }
        
        @media (max-width: 600px) {
            .hero {
                padding: 70px 0 40px;
            }
            
            .hero h1 {
                font-size: 2rem;
            }
            
            .story {
                padding: 50px 0;
            }
        }
    </style>
</head>
<body>
    <!-- Hero Section -->
    <section class="hero">
        <div class="container hero-content">
            <h1><?php echo htmlspecialchars($about['hero_title']); ?></h1>
            <p><?php echo nl2br(htmlspecialchars($about['hero_description'])); ?></p>
        </div>
    </section>
    
    <!-- Our Story Section -->
    <section class="story">
        <div class="container story-container">
            <div class="story-image">
                <img src="../uploads/<?php echo htmlspecialchars($about['story_image']); ?>" alt="Our venue history">
            </div>
            <div class="story-content">
                <h2><?php echo htmlspecialchars($about['story_title']); ?></h2>
                <p><?php echo nl2br(htmlspecialchars($about['story_description'])); ?></p>
            </div>
        </div>
    </section>
</body>
</html>
