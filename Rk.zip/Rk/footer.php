<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Beautiful Footer Example</title>
  <style>
    /* Reset and base styles */
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      background-color: #f5f5f5;
    }
    
    main {
      flex: 1;
      padding: 2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      color: #333;
    }
    
    /* Footer styles */
    footer {
      background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
      color: white;
      padding: 4rem 2rem 2rem;
      position: relative;
      overflow: hidden;
    }
    
    .footer-wave {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      overflow: hidden;
      line-height: 0;
    }
    
    .footer-wave svg {
      position: relative;
      display: block;
      width: calc(100% + 1.3px);
      height: 46px;
      transform: rotateY(180deg);
    }
    
    .footer-wave .shape-fill {
      fill: #f5f5f5;
    }
    
    .footer-container {
      max-width: 1200px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 2rem;
    }
    
    .footer-column {
      animation: fadeIn 0.8s ease-in-out forwards;
      opacity: 0;
    }
    
    .footer-column:nth-child(1) { animation-delay: 0.1s; }
    .footer-column:nth-child(2) { animation-delay: 0.3s; }
    .footer-column:nth-child(3) { animation-delay: 0.5s; }
    .footer-column:nth-child(4) { animation-delay: 0.7s; }
    
    .footer-logo {
      font-size: 1.8rem;
      font-weight: 700;
      margin-bottom: 1rem;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    
    .footer-logo-icon {
      background-color: white;
      color: #6366f1;
      width: 36px;
      height: 36px;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: bold;
    }
    
    .footer-description {
      margin-bottom: 1.5rem;
      line-height: 1.6;
      color: rgba(255, 255, 255, 0.8);
    }
    
    .footer-heading {
      font-size: 1.2rem;
      font-weight: 600;
      margin-bottom: 1.2rem;
      position: relative;
      padding-bottom: 0.5rem;
    }
    
    .footer-heading::after {
      content: '';
      position: absolute;
      left: 0;
      bottom: 0;
      width: 40px;
      height: 3px;
      background-color: white;
      transition: width 0.3s ease;
    }
    
    .footer-column:hover .footer-heading::after {
      width: 60px;
    }
    
    .footer-links {
      list-style: none;
    }
    
    .footer-links li {
      margin-bottom: 0.8rem;
    }
    
    .footer-links a {
      color: rgba(255, 255, 255, 0.8);
      text-decoration: none;
      transition: all 0.3s ease;
      position: relative;
      display: inline-block;
    }
    
    .footer-links a::after {
      content: '';
      position: absolute;
      width: 0;
      height: 1px;
      bottom: -2px;
      left: 0;
      background-color: white;
      transition: width 0.3s ease;
    }
    
    .footer-links a:hover {
      color: white;
      transform: translateX(5px);
    }
    
    .footer-links a:hover::after {
      width: 100%;
    }
    
    .social-icons {
      display: flex;
      gap: 1rem;
      margin-top: 1.5rem;
    }
    
    .social-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background-color: rgba(255, 255, 255, 0.1);
      color: white;
      text-decoration: none;
      transition: all 0.3s ease;
    }
    
    .social-icon:hover {
      background-color: white;
      color: #6366f1;
      transform: translateY(-5px);
    }
    
    .newsletter-form {
      display: flex;
      margin-top: 1rem;
    }
    
    .newsletter-input {
      flex: 1;
      padding: 0.8rem 1rem;
      border: none;
      border-radius: 4px 0 0 4px;
      outline: none;
      font-size: 0.9rem;
    }
    
    .newsletter-button {
      background-color: white;
      color: #6366f1;
      border: none;
      padding: 0 1.2rem;
      border-radius: 0 4px 4px 0;
      cursor: pointer;
      font-weight: 600;
      transition: all 0.3s ease;
    }
    
    .newsletter-button:hover {
      background-color: #f0f0f0;
    }
    
    .footer-bottom {
      margin-top: 3rem;
      padding-top: 1.5rem;
      border-top: 1px solid rgba(255, 255, 255, 0.1);
      text-align: center;
      color: rgba(255, 255, 255, 0.7);
      font-size: 0.9rem;
      animation: fadeIn 0.8s ease-in-out 0.9s forwards;
      opacity: 0;
    }
    
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
    
    /* Responsive adjustments */
    @media (max-width: 768px) {
      .footer-container {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      }
    }
    
    @media (max-width: 480px) {
      footer {
        padding: 3rem 1.5rem 1.5rem;
      }
      
      .footer-container {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <main>
    <p><b>Life is short, but there is always time for cookies.</b></p>
  </main>
  
  <footer>
    <div class="footer-wave">
      <svg data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
        <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z" class="shape-fill"></path>
      </svg>
    </div>
    
    <div class="footer-container">
      <div class="footer-column">
        <div class="footer-logo">
          <div class="footer-logo-icon">E</div>
          <span>Event Management</span>
        </div>
        <p class="footer-description">
          We specialize in organizing unforgettable events, creating memories that last a lifetime.
        </p>
        <div class="social-icons">
          <a href="#" class="social-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg>
          </a>
          <a href="#" class="social-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"></path></svg>
          </a>
          <a href="#" class="social-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>
          </a>
          <a href="#" class="social-icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg>
          </a>
        </div>
      </div>
      
      <div class="footer-column">
        <h3 class="footer-heading">Company</h3>
        <ul class="footer-links">
          <li><a href="/Rk/ABOUTUS/about.php">About Us</a></li>
          <li><a href="/Rk/BOOKED/events.php">Our Events</a></li>
          <li><a href="/Rk/CONTACT/Contact_list.php">Contact Us</a></li>
          <li><a href="#">Privacy Policy</a></li>
          <li><a href="#">Careers</a></li>
        </ul>
      </div>
      
      <div class="footer-column">
        <h3 class="footer-heading">Services</h3>
        <ul class="footer-links">
          <li><a href="#">Wedding Planning</a></li>
          <li><a href="#">Corporate Events</a></li>
          <li><a href="#">Birthday Parties</a></li>
          <li><a href="#">Concerts</a></li>
          <li><a href="#">Custom Events</a></li>
        </ul>
      </div>
      
      <div class="footer-column">
        <h3 class="footer-heading">Newsletter</h3>
        <p class="footer-description">Subscribe to stay updated on our latest events and offers.</p>
        <form class="newsletter-form">
          <input type="email" class="newsletter-input" placeholder="Enter your email">
          <button type="submit" class="newsletter-button">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"></line><polygon points="22 2 15 22 11 13 2 9 22 2"></polygon></svg>
          </button>
        </form>
      </div>
    </div>
    
    <div class="footer-bottom">
      <p>&copy; 2025 Event Management. All rights reserved.</p>
    </div>
  </footer>
</body>
</html>