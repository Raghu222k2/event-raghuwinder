<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include_once "db.php";

$userProfilePicture = null;
$userRole = null; // Add a variable to store the user's role
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $sql = "SELECT profile_picture, role FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $stmt->bind_result($profilePicture, $role);
    if ($stmt->fetch()) {
        $userProfilePicture = $profilePicture;
        $userRole = $role; // Fetch the user's role
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events Navbar</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="fontawesome/css/all.css">
    <!-- Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="js/jquery-3.7.1.min.js"></script>
    <script src="js/jquery.validate.min.js"></script>
    <script src="js/additional-methods.min.js"></script>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center; /* Ensures vertical centering */
            padding: 10px 50px;
            height: 60px;
            background: linear-gradient(to right,rgb(62, 63, 123) 0%,rgb(119, 75, 222) 100%);
            border-bottom: 1px solid #ddd;
            position: relative; /* Ensure consistent positioning */
        }
        .left-section {
            display: flex;
            align-items: center;
        }
        .logo {
            display: flex;
            align-items: center;
            font-size: 24px;
            font-weight: bold;
            color: white;
            text-decoration: none;
        }
        .event-icon {
            font-size: 24px;
            color: white;
            cursor: pointer;
            margin-right: 5px;
        }
        .nav-links {
            list-style: none;
            display: flex;
            justify-content: center; /* Center the navigation links */
            flex-grow: 1; /* Allow the nav-links to take up available space */
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            margin: 0 15px;
        }
        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 16px;
            font-weight: 500;
            transition: color 0.3s ease-in-out;
        }
        .nav-links a:hover {
            color:rgb(24, 202, 30);
        }
        .login-btn {
            display: flex;
            align-items: center; /* Centers content vertically */
            justify-content: center;
            padding: 8px 15px;
            background: white;
            color: #6366f1;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            font-weight: bold;
            transition: background 0.3s ease-in-out, color 0.3s ease-in-out, transform 0.2s;
        }
        .login-btn:hover {
            background: #f1f1f1;
            color: #4f46e5;
            transform: scale(1.05);
        }
        .profile-img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            cursor: pointer;
        }
        .profile-dropdown {
            position: relative; /* Ensure proper stacking context */
            z-index: 1050; /* Higher than the carousel */
        }
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 150px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1060; /* Ensure it appears above the carousel */
            border-radius: 5px;
        }
        .dropdown-content a {
            color: black;
            padding: 10px 15px;
            text-decoration: none;
            display: block;
            font-size: 14px;
        }
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        .profile-dropdown:hover .dropdown-content {
            display: block;
        }
        .nav-toggler {
            display: none;
            background-color: #343a40;
            color: white;
            border: none;
            border-radius: 5px;
            padding: 8px 12px;
            cursor: pointer;
            position: absolute;
            top: 50%; /* Center vertically */
            transform: translateY(-50%); /* Adjust for exact centering */
            left: 10px; /* Align to the left */
        }
        .nav-toggler:focus {
            outline: none;
        }
        .navbar-right {
            position: absolute;
            right: 10px; /* Align to the right corner */
            top: 50%; /* Center vertically */
            transform: translateY(-50%);
            display: flex;
            align-items: center;
        }
        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
                padding: 10px;
                position: relative;
            }
            .nav-links {
                display: none;
                flex-direction: column;
                text-align: left;
                background-color: rgb(62, 63, 123);
                padding: 10px;
                position: absolute;
                top: 60px;
                left: 0;
                width: 100%;
                z-index: 1040;
            }
            .nav-links.active {
                display: flex;
            }
            .nav-toggler {
                display: block;
            }
            .nav-links li {
                margin: 5px 0;
            }
        }
    </style>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const toggler = document.querySelector(".nav-toggler");
            const navLinks = document.querySelector(".nav-links");

            toggler.addEventListener("click", function () {
                navLinks.classList.toggle("active");
            });
        });
    </script>
</head>
<body>
    <nav class="navbar">
        <div class="left-section">
            <button class="nav-toggler">☰</button>
            <span class="event-icon">&#128197;</span>
            <a href="/Rk/index.php" class="logo">EVENTS</a>
        </div>
        <ul class="nav-links">
            <li><a href="/Rk/index.php" class="active">Home</a></li>
            <li><a href="/Rk/VENUES/venues_list.php">Venues</a></li>
            <li><a href="/Rk/BOOKED/events.php">Events</a></li>
            <li><a href="/Rk/EVENTPLANNER/planner_list.php">Events Planner</a></li>
            <li><a href="/Rk/OFFERS/offers_list.php">Deals</a></li>
            <li><a href="/Rk/ABOUTUS/about.php">About Us</a></li>
            <li><a href="/Rk/CONTACT/Contact_list.php">Contact</a></li>
            <?php if ($userRole === 'admin'): // Show Dashboard only for admin ?>
                <li><a href="/Rk/dashboard.php">Dashboard</a></li>
            <?php endif; ?>
        </ul>
        <div class="navbar-right">
            <?php if ($userProfilePicture): ?>
                <div class="profile-dropdown">
                    <img src="/Rk/<?php echo $userProfilePicture; ?>" alt="Profile Picture" class="profile-img">
                    <div class="dropdown-content">
                        <a href="/Rk/profile.php">Profile</a>
                        <a href="/Rk/logout.php">Logout</a>
                    </div>
                </div>
            <?php else: ?>
                <button class="login-btn" onclick="window.location.href='/Rk/logins/signIn.php'">Login</button>
            <?php endif; ?>
        </div>
    </nav>
</body>
</html>




