<?php
include_once "../db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['photo'])) {
    $file = $_FILES['photo'];
    $filename = basename($file['name']);
    $uploadDir = __DIR__ . '/uploads/';
        $webPath = 'GALLERY/uploads/' . $filename; // Updated to include the relative path from the web root

    // Ensure the uploads directory exists
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    if (move_uploaded_file($file['tmp_name'], $uploadDir . $filename)) {
        $stmt = $conn->prepare("INSERT INTO gallery (filename, filepath) VALUES (?, ?)");
        $stmt->bind_param("ss", $filename, $webPath);
        $stmt->execute();

        // Add photo to the database for both gallery and carousel
        $photo = [
            'id' => $stmt->insert_id,
            'filename' => $filename,
            'filepath' => $webPath
        ];

        echo json_encode(['success' => true, 'photo' => $photo]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to upload photo']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'No photo uploaded']);
}
?>
