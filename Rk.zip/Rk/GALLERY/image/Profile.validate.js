
$(document).ready(function () {
    $("#profileForm").validate({
        rules: {


            name: {
                required: true,
                minlength: 3,
                maxlength: 50,
                pattern: /^[a-zA-Z\s]*$/
            },
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 8,
                maxlength: 20,
                pattern: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,20}$/
            },

            cpassword: {
                required: true,
                equalTo: "#password"
            },

            mobile: {
                required: true,
                number: true,
                pattern: /^[0-9]{10}$/
            },

            date: {
                required: true,
                date: true
            },

            city: {
                required: true,
                minlength: 3,
                maxlength: 50,
                pattern: /^[a-zA-Z\s]*$/
            },
            zip: {
                required: true,
                number: true,
                pattern: /^[0-9]{6}$/
            },
            address: {
                required: true,
                minlength: 10,
                maxlength: 200,
                pattern: /^[a-zA-Z\s]*$/
            }
        },

        messages: {
            name: {
                required: "Please enter your name",
                minlength: "Your name must consist of at least 3 characters",
                maxlength: "Your name must consist of at most 50 characters",
                pattern: "Please enter a valid name"
            },
            email: {
                required: "Please enter your email",
                email: "Please enter a valid email"
            },
            password: {
                required: "Please enter your password",
                minlength: "Your password must consist of at least 8 characters",
                maxlength: "Your password must consist of at most 20 characters",
                pattern: "Password must contain at least one number, one uppercase and one lowercase letter"
            },

            cpassword: {
                required: "Please enter your password",
                equalTo: "Password does not match"
            },

            mobile: {
                required: "Please enter your mobile number",
                number: "Please enter a valid mobile number",
                pattern: "Please enter a valid mobile number"
            },

            date: {
                required: "Please enter your date of birth",
                date: "Please enter a valid date of birth"
            },

            city: {
                required: "Please enter your city",
                minlength: "Your city must consist of at least 3 characters",
                maxlength: "Your city must consist of at most 50 characters",
                pattern: "Please enter a valid city"
            },
            zip: {
                required: "Please enter your zip code",
                number: "Please enter a valid zip code",
                pattern: "Please enter a valid zip code"
            },
            address: {
                required: "Please enter your address",
                minlength: "Your address must consist of at least 10 characters",
                maxlength: "Your address must consist of at most 200 characters",
                pattern: "Please enter a valid address"
            }
        },

        errorElement: "div",

        errorPlacement: function (error, element) {
            error.addClass("invalid-feedback");
            error.insertAfter(element);
        },

        highlight: function (element, errorClass, validClass) {
            $(element).addClass("is-invalid").removeClass("is-valid");
        },

        unhighlight: function (element, errorClass, validClass) {
            $(element).addClass("is-valid").removeClass("is-invalid");
        },

        submitHandler: function (form, event) {
            event.preventDefault();
            form.reset();
            $(form).find('.is-valid, .is-invalid').removeClass('is-valid is-invalid');

        }
    });
})