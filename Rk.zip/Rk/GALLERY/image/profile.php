<?php include_once 'header.php'; ?>
<?php include_once 'nav.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-6">
            <div class="card border-secondary border-2 shadow">
                <div class="card-body text-center">
                    <form id="profileForm" action="update_profile.php" method="POST">
                        <label for="" class="fw-medium fs-4 mb-3">Edit Profile</label>
                        <div class="row">
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Full Name" required>
                                    <label for="name" class="text-secondary">Full Name</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
                                    <label for="email" class="text-secondary">Email address</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
                                    <label for="password" class="text-secondary">Password</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Confirm Password" required>
                                    <label for="cpassword" class="text-secondary">Confirm Password</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="mobile" name="mobile" placeholder="Mobile" required>
                                    <label for="mobile" class="text-secondary">Mobile</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="date" class="form-control" id="date" name="date" required>
                                    <label for="date">Date of Birth</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="text" class="form-control" id="city" name="city" placeholder="City Name" required>
                                    <label for="city" class="text-secondary">City Name</label>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-floating mb-3">
                                    <input type="number" class="form-control" id="zip" name="zip" placeholder="Zip Code" required>
                                    <label for="zip" class="text-secondary">Zip Code</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating mb-3">
                                    <textarea class="form-control" id="address" name="address" placeholder="Address" required></textarea>
                                    <label for="address" class="text-secondary">Address</label>
                                </div>
                            </div>
                        </div>
                        <hr class="black text-black">
                        <button class="btn btn-dark fw-medium" type="submit">
                            Save Details
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="Profile.validate.js"></script>

<?php include_once 'footer.php'; ?>
