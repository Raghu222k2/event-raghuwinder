<?php
include_once "../db.php";

$result = $conn->query("SELECT id, filename, filepath FROM gallery");
$photos = [];

while ($row = $result->fetch_assoc()) {
    $photos[] = $row;
}

echo json_encode($photos);
?>
