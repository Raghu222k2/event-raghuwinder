<?php include_once "../navbar.php" ?>
<?php include_once "../db.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Photo Gallery</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f4f4f9;
    }
    .container {
      padding: 20px;
    }
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }
    .header h1 {
      font-size: 24px;
      color: #333;
    }
    .upload-button {
      display: inline-flex;
      align-items: center;
      padding: 10px 15px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      text-decoration: none;
    }
    .upload-button:hover {
      background-color: #0056b3;
    }
    .gallery {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
      gap: 20px;
    }
    .photo-card {
      background-color: white;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      overflow: hidden;
    }
    .photo-container img {
      width: 100%;
      height: 150px;
      object-fit: cover;
    }
    .photo-footer {
      padding: 10px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .filename {
      font-size: 14px;
      color: #555;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .delete-button {
      background: none;
      border: none;
      cursor: pointer;
      color: #e74c3c;
    }
    .delete-button:hover {
      color: #c0392b;
    }
    .empty-state {
      text-align: center;
      color: #888;
      font-size: 16px;
    }
    .hidden {
      display: none;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Photo Gallery</h1>
      <div>
        <input type="file" id="photo-upload" accept="image/*" multiple class="hidden">
        <label for="photo-upload" class="upload-button">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
            <polyline points="17 8 12 3 7 8"></polyline>
            <line x1="12" y1="3" x2="12" y2="15"></line>
          </svg>
          Add Photo
        </label>
      </div>
    </div>

    <div id="empty-state" class="empty-state">
      <p>No photos yet. Click "Add Photo" to upload.</p>
    </div>

    <div id="gallery" class="gallery"></div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const photoUploadInput = document.getElementById('photo-upload');
      const galleryElement = document.getElementById('gallery');
      const emptyStateElement = document.getElementById('empty-state');
      let photos = [];

      // Fetch existing photos from the database
      fetch('fetch_photos.php')
        .then(response => response.json())
        .then(data => {
          if (data.length > 0) {
            photos = data;
            renderGallery();
          }
        })
        .catch(error => {
          console.error('Error fetching photos:', error);
        });

      // Handle file upload
      photoUploadInput.addEventListener('change', function(event) {
        const files = event.target.files;
        if (!files || files.length === 0) return;

        // Process each uploaded file
        Array.from(files).forEach(file => {
          const formData = new FormData();
          formData.append('photo', file);

          fetch('upload_photo.php', {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => {
            if (data.success) {
              photos.push(data.photo);
              renderGallery();
            } else {
              console.error('Error uploading photo:', data.message);
            }
          })
          .catch(error => {
            console.error('Error uploading photo:', error);
          });
        });

        // Reset the file input
        event.target.value = "";
      });

      // Function to delete a photo
      function deletePhoto(id) {
        fetch(`delete_photo.php?id=${id}`, {
          method: 'GET'
        })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            photos = photos.filter(photo => photo.id !== id);
            renderGallery();
          } else {
            console.error('Error deleting photo:', data.message);
          }
        })
        .catch(error => {
          console.error('Error deleting photo:', error);
        });
      }

      // Function to render the gallery
      function renderGallery() {
        if (photos.length === 0) {
          emptyStateElement.classList.remove('hidden');
          galleryElement.classList.add('hidden');
          return;
        }

        emptyStateElement.classList.add('hidden');
        galleryElement.classList.remove('hidden');
        
        // Clear the gallery
        galleryElement.innerHTML = '';
        
        // Add each photo to the gallery
        photos.forEach(photo => {
          const photoName = photo.filename.split('.')[0]; // Remove the file extension

          const photoCard = document.createElement('div');
          photoCard.className = 'photo-card';
          photoCard.innerHTML = `
            <div class="photo-container">
              <img src="../${photo.filepath}" alt="${photoName}">
            </div>
            <div class="photo-footer">
              <p class="filename" title="${photo.filename}">${photoName}</p>
              <button class="delete-button" data-id="${photo.id}">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                  <polyline points="3 6 5 6 21 6"></polyline>
                  <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                  <line x1="10" y1="11" x2="10" y2="17"></line>
                  <line x1="14" y1="11" x2="14" y2="17"></line>
                </svg>
              </button>
            </div>
          `;
          
          galleryElement.appendChild(photoCard);
          
          // Add event listener to delete button
          const deleteButton = photoCard.querySelector('.delete-button');
          deleteButton.addEventListener('click', function() {
            const id = this.getAttribute('data-id');
            deletePhoto(id);
          });
        });
      }

      // Initial render
      renderGallery();
    });
  </script>
</body>
</html>