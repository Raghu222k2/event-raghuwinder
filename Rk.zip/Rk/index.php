<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<?php 
include_once("header.php");
include_once("db.php");
?>

<style>
.carousel-indicators {
    bottom: 10px !important;
}
.carousel-indicators button {
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background-color: white;
}
.carousel {
    position: relative;
    z-index: 1; /* Lower than the dropdown menu */
}
.carousel-inner {
    position: relative;
    z-index: 1; /* Ensure the carousel content is behind the dropdown */
}
.carousel-inner img {
    border-radius: 20px; /* Add border-radius to slider images */
    object-fit: cover; /* Ensure images maintain aspect ratio */
    height: 650px; /* Set a fixed height for consistency */
    width: 100%; /* Ensure images span the full width */
}
@media (max-width: 768px) {
    .carousel-inner img {
        height: 300px; /* Adjust height for smaller screens */
    }
    .carousel-caption h3 {
        font-size: 1.2rem; /* Adjust caption font size */
    }
}
</style>
<br>
<div class="container">
<!-- <h1 class="text-center">WECOME TO THE DRIVE OF EVENTS </h1> -->
    <div id="demo" class="carousel slide" data-bs-ride="carousel">
        <!-- Indicators -->
        <div class="carousel-indicators">
            <?php
            $result = $conn->query("SELECT id FROM gallery");
            $count = $result->num_rows;
            for ($i = 0; $i < $count; $i++) {
                $active = $i === 0 ? "active" : "";
                echo "<button type='button' data-bs-target='#demo' data-bs-slide-to='$i' class='$active'></button>";
            }
            ?>
        </div>
        
        <!-- Slideshow -->
        <div class="carousel-inner">
            <?php
            $result = $conn->query("SELECT filepath, filename FROM gallery");
            if ($result->num_rows > 0) {
                $isActive = true;
                while ($row = $result->fetch_assoc()) {
                    $activeClass = $isActive ? "active" : "";
                    $isActive = false;

                    // Extract the filename without the extension
                    $photoName = pathinfo($row['filename'], PATHINFO_FILENAME);

                    echo "
                    <div class='carousel-item $activeClass'>
                        <img src='{$row['filepath']}' alt='{$photoName}' class='d-block w-100'>
                        <div class='carousel-caption'>
                            <h3>{$photoName}</h3>
                        </div>
                    </div>";
                }
            } else {
                echo "
                <div class='carousel-item active'>
                    <img src='images/default.jpg' alt='Default Image' class='d-block w-100'>
                    <div class='carousel-caption'>
                        <h3>No Images Available</h3>
                    </div>
                </div>";
            }
            ?>
        </div>
        
        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</div>

<div class="container mt-5">
    <h1 class="text-center">What We Organize</h1>
    <hr>
</div>

<!-- Event Sections -->
<div class="container">
    <?php 
    $events = [
        ["Wedding", "images/wedding2.jpg", "The most important day in a couple's life.", "http://localhost/Rk/BOOKED/events.php"],
        ["Birthday", "images/birthday2.jpg", "Celebrate with your loved ones in style.", "http://localhost/Rk/BOOKED/events.php"],
        // ["Fashion", "images/fashion2.jpg", "Showcase your latest fashion trends.", "http://localhost/Rk/BOOKED/events.php"],
        // ["Meeting", "images/meeting2.jpg", "Host professional business meetings.", "http://localhost/Rk/BOOKED/events.php"]
    ];
    
    foreach ($events as $event) {
        echo "<div class='row my-5 align-items-center'>
                <div class='col-md-6 col-sm-12 mb-3'>
                    <img src='{$event[1]}' class='img-fluid rounded'>
                </div>
                <div class='col-md-6 col-sm-12'>
                    <h2>{$event[0]}</h2>
                    <p>{$event[2]}</p>
                    <a href='{$event[3]}' class='btn btn-primary bg-dark'>View Events</a>
                </div>
              </div>
              <hr>";
    }
    ?>
</div>

<?php include_once("footer.php"); ?>

