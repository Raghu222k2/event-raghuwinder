<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php"); // Redirect to login if not logged in or invalid user
    exit();
}
?>
<?php include_once "../navbar.php" ?>
<?php include_once "../db.php" ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients Lists</title>
    <link rel="stylesheet" href="../style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            // Fetch and display users from the database
            function fetchUsers() {
                $.ajax({
                    url: 'fetch_users.php',
                    type: 'GET',
                    success: function(response) {
                        $('table tbody').html(response);
                    }
                });
            }

            fetchUsers();

            // Custom method for name validation (letters and spaces only)
            $.validator.addMethod("lettersonly", function(value, element) {
                return this.optional(element) || /^[a-zA-Z\s]+$/.test(value);
            }, "Please enter only letters");

            // Custom method for email validation
            $.validator.addMethod("email", function(value, element) {
                return this.optional(element) || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
            }, "Please enter a valid email address");

            $('#editUserForm').validate({
                rules: {
                    editUserName: {
                        required: true,
                        minlength: 2,
                        lettersonly: true
                    },
                    editUserEmail: {
                        required: true,
                        email: true
                    },
                    editUserGender: {
                        required: true
                    },
                    editUserStatus: {
                        required: true
                    }
                },
                messages: {
                    editUserName: {
                        required: "Please enter the name",
                        minlength: "Name must be at least 2 characters long",
                        lettersonly: "Please enter only letters"
                    },
                    editUserEmail: {
                        required: "Please enter the email",
                        email: "Please enter a valid email address"
                    },
                    editUserGender: {
                        required: "Please select the gender"
                    },
                    editUserStatus: {
                        required: "Please select a status"
                    }
                },
                submitHandler: function(form) {
                    const userId = $('#editUserId').val();
                    const userName = $('#editUserName').val().trim();
                    const userEmail = $('#editUserEmail').val().trim();
                    const userGender = $('#editUserGender').val();
                    const userStatus = $('#editUserStatus').val();

                    $.ajax({
                        url: 'update_user.php',
                        type: 'POST',
                        data: {
                            id: userId,
                            name: userName,
                            email: userEmail,
                            gender: userGender,
                            status: userStatus
                        },
                        success: function(response) {
                            fetchUsers();
                            $('#editUserModal').modal('hide');
                        }
                    });
                }
            });

            $('#addUserForm').validate({
                rules: {
                    addUserName: {
                        required: true,
                        minlength: 2,
                        lettersonly: true
                    },
                    addUserEmail: {
                        required: true,
                        email: true
                    },
                    addUserGender: {
                        required: true
                    },
                    addUserStatus: {
                        required: true
                    }
                },
                messages: {
                    addUserName: {
                        required: "Please enter the name",
                        minlength: "Name must be at least 2 characters long",
                        lettersonly: "Please enter only letters"
                    },
                    addUserEmail: {
                        required: "Please enter the email",
                        email: "Please enter a valid email address"
                    },
                    addUserGender: {
                        required: "Please select the gender"
                    },
                    addUserStatus: {
                        required: "Please select a status"
                    }
                },
                submitHandler: function(form) {
                    const userName = $('#addUserName').val().trim();
                    const userEmail = $('#addUserEmail').val().trim();
                    const userGender = $('#addUserGender').val();
                    const userStatus = $('#addUserStatus').val();

                    $.ajax({
                        url: 'add_user.php',
                        type: 'POST',
                        data: {
                            name: userName,
                            email: userEmail,
                            gender: userGender,
                            status: userStatus
                        },
                        success: function(response) {
                            fetchUsers();
                            $('#addUserModal').modal('hide');
                        }
                    });
                }
            });

            $(document).on('click', '.edit-btn', function() {
                const row = $(this).closest('tr');
                const userId = row.find('td:eq(0)').text();
                const userName = row.find('td:eq(1)').text();
                const userEmail = row.find('td:eq(2)').text();
                const userGender = row.find('td:eq(3)').text();
                const userStatus = row.find('td:eq(5) .status').hasClass('status-active') ? 'Active' : 'Inactive';

                $('#editUserId').val(userId);
                $('#editUserName').val(userName);
                $('#editUserEmail').val(userEmail);
                $('#editUserGender').val(userGender);
                $('#editUserStatus').val(userStatus);

                $('#editUserModal').modal('show');
            });

            $(document).on('click', '.delete-btn', function() {
                const row = $(this).closest('tr');
                const userId = row.find('td:eq(0)').text();

                $.ajax({
                    url: 'delete_user.php',
                    type: 'POST',
                    data: { id: userId },
                    success: function(response) {
                        fetchUsers();
                    }
                });
            });

            $('.add-user-btn').on('click', function() {
                $('#addUserModal').modal('show');
            });

            function updateSerialNumbers() {
                $('table tbody tr').each(function(index) {
                    $(this).find('td:eq(0)').text(index + 1);
                });
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">CLIENTS LISTS</h1>
            <button class="add-user-btn">ADD USER</button>
        </div>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>Actions</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Users will be fetched here -->
                </tbody>
            </table>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div class="modal fade" id="editUserModal" tabindex="-1" aria-labelledby="editUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editUserModalLabel">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="editUserForm">
                        <input type="hidden" id="editUserId">
                        <div class="mb-3">
                            <label for="editUserName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="editUserName" name="editUserName" required>
                        </div>
                        <div class="mb-3">
                            <label for="editUserEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="editUserEmail" name="editUserEmail" required>
                        </div>
                        <div class="mb-3">
                            <label for="editUserGender" class="form-label">Gender</label>
                            <select class="form-control" id="editUserGender" name="editUserGender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="editUserStatus" class="form-label">Status</label>
                            <select class="form-control" id="editUserStatus" name="editUserStatus" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Add User Modal -->
    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addUserModalLabel">Add User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addUserForm">
                        <div class="mb-3">
                            <label for="addUserName" class="form-label">Name</label>
                            <input type="text" class="form-control" id="addUserName" name="addUserName" required>
                        </div>
                        <div class="mb-3">
                            <label for="addUserEmail" class="form-label">Email</label>
                            <input type="email" class="form-control" id="addUserEmail" name="addUserEmail" required>
                        </div>
                        <div class="mb-3">
                            <label for="addUserGender" class="form-label">Gender</label>
                            <select class="form-control" id="addUserGender" name="addUserGender" required>
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="addUserStatus" class="form-label">Status</label>
                            <select class="form-control" id="addUserStatus" name="addUserStatus" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Add User</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>