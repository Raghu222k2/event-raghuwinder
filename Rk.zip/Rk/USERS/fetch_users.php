<?php
include_once "../db.php";

$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['name']}</td>
                <td>{$row['email']}</td>
                <td>{$row['gender']}</td>
                <td>
                    <button class='action-btn edit-btn'>Edit</button>
                    <button class='action-btn delete-btn'>Delete</button>
                </td>
                <td><span class='status " . ($row['status'] === 'Active' ? 'status-active' : 'status-inactive') . "'>{$row['status']}</span></td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No users found</td></tr>";
}

$conn->close();
?>
