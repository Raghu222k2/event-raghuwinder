<?php
include_once "../db.php";

$id = $_POST['id'];
$name = $_POST['name'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$status = $_POST['status'];

$sql = "UPDATE users SET name=?, email=?, gender=?, status=? WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $name, $email, $gender, $status, $id);

if ($stmt->execute()) {
    echo "User updated successfully";
} else {
    echo "Error updating user: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
