<?php
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';
include_once "../db.php";

use PHPMailer\PHPMailer\PHPMailer;

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email address.']);
        exit();
    }

    try {
        $sql = "SELECT id FROM users WHERE email = ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            echo json_encode(['success' => false, 'message' => 'Database error.']);
            exit();
        }
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 0) {
            echo json_encode(['success' => false, 'message' => 'No account found with this email.']);
            exit();
        }

        $otp = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);

        $sql = "UPDATE users SET otp = ?, otp_expiration = DATE_ADD(NOW(), INTERVAL 10 MINUTE) WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $otp, $email);
        $stmt->execute();

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = getenv('SMTP_EMAIL'); // Use environment variable
            $mail->Password = getenv('SMTP_PASSWORD'); // Use environment variable
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom(getenv('SMTP_EMAIL'), 'Your App Name'); // Use environment variable
            $mail->addAddress($email);
            $mail->isHTML(true);
            $mail->Subject = 'Your OTP Code';
            $mail->Body = "Your OTP code is <b>$otp</b>. It will expire in 10 minutes.";

            $mail->send();
            echo json_encode(['success' => true, 'message' => 'OTP sent successfully.']);
        } catch (Exception $e) {
            error_log("Mailer Error: " . $mail->ErrorInfo); // Log detailed error
            echo json_encode(['success' => false, 'message' => 'Failed to send OTP. Please check your email configuration.']);
        }
    } catch (Exception $e) {
        error_log("Error: " . $e->getMessage()); // Log any other errors
        echo json_encode(['success' => false, 'message' => 'An unexpected error occurred.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method.']);
}
?>
