<?php
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = getenv('SMTP_EMAIL'); // Use environment variable
    $mail->Password = getenv('SMTP_PASSWORD'); // Use environment variable
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;

    $mail->setFrom(getenv('SMTP_EMAIL'), 'Test App'); // Use environment variable
    $mail->addAddress('recipient_email@example.com'); // Replace with a test recipient email
    $mail->isHTML(true);
    $mail->Subject = 'SMTP Test';
    $mail->Body = 'This is a test email to verify SMTP configuration.';

    $mail->send();
    echo "SMTP Test Email Sent Successfully!";
} catch (Exception $e) {
    echo "SMTP Test Failed: " . $mail->ErrorInfo;
}
?>
