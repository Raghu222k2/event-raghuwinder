<?php
session_start();
include_once "../db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the email exists in the database
    $sql = "SELECT id, password, role FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($userId, $hashedPassword, $role);

    if ($stmt->fetch()) {
        // Verify the password
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['user_id'] = $userId; // Set the session variable
            if ($role === 'admin') {
                header("Location: ../dashboard.php"); // Redirect to the admin dashboard
            } else {
                header("Location: ../index.php"); // Redirect to the homepage
            }
            exit();
        } else {
            error_log("Invalid password for email: $email"); // Log invalid password
            $error = "Invalid password. Please try again.";
        }
    } else {
        error_log("No account found for email: $email"); // Log email not found
        $error = "No account found with this email. Please sign up.";
    }

    $stmt->close();
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f0ff;
        }

        .container {
            display: flex;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
        }

        .left {
            flex: 1;
            background: #e5e1f7;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
            text-align: center;
        }

        .left img {
            width: 100%;
            max-width: 300px;
            height: auto;
        }

        .left h2 {
            margin-top: 15px;
            color: #6a0dad;
        }

        .right {
            flex: 1;
            padding: 40px;
        }

        .right h2 {
            color: #6a0dad;
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .remember {
            display: flex;
            align-items: center;
        }

        .remember input {
            margin-right: 5px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background: #6a0dad;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        .btn:hover {
            background: #570b9c;
        }

        .login-link {
            text-align: center;
            margin-top: 10px;
        }

        .login-link a {
            color: #6a0dad;
            text-decoration: none;
        }

        .forgot-password {
            margin-left: 10px;
            color: #6a0dad;
            text-decoration: none;
        }

        .forgot-password:hover {
            text-decoration: underline;
        }

        label.error {
            color: #ff6666; /* Light red color for validation errors */
            font-size: 14px;
            margin-top: 5px;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                box-shadow: none;
                border-radius: 0;
            }
            .left {
                padding: 10px;
            }
            .right {
                padding: 20px;
            }
            .form-group input {
                font-size: 14px;
            }
            .btn {
                font-size: 14px;
            }
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function () {
            $("#signInForm").validate({
                rules: {
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 6
                    }
                },
                messages: {
                    email: {
                        required: "Please enter your email address",
                        email: "Please enter a valid email address"
                    },
                    password: {
                        required: "Please provide your password",
                        minlength: "Your password must be at least 6 characters long"
                    }
                }
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="left">
            <img src="sign in.svg" alt="Sign In Illustration">
            <h2>Welcome Back</h2>
            <p>Sign in to access your account</p>
        </div>
        <div class="right">
            <h2>Sign In</h2>
            <p>Enter your credentials to continue</p>

            <form id="signInForm" method="POST" action="">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="john@example.com" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <?php if (isset($error)): ?>
                <p style="color: #ff6666; font-size: 14px;"><?php echo $error; ?></p>
                <?php endif; ?>
                <div class="remember">
                    <input type="checkbox" id="remember">
                    <label for="remember">Remember me</label>
                    <a href="forgotPassword.php" class="forgot-password">Forgot Password?</a>
                </div>
                <button type="submit" class="btn">Sign In</button>
            </form>
            <p class="login-link">Don't have an account? <a href="signup.php">Sign up</a></p>
        </div>
    </div>
</body>
</html>
