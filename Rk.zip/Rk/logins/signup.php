<?php
include_once "../db.php";
session_start();

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];
    $gender = $_POST['gender'];
    $status = "Active"; // Default status for new users

    // Server-side validation
    if (empty($name) || strlen($name) < 2) {
        $error = "Name must be at least 2 characters long.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address.";
    } elseif (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long.";
    } elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } elseif (empty($gender)) {
        $error = "Please select your gender.";
    } elseif (!isset($_FILES['profile_picture']) || $_FILES['profile_picture']['error'] !== UPLOAD_ERR_OK) {
        $error = "Please upload a valid profile picture.";
    }

    if (!$error) {
        // Handle profile picture upload
        $profilePicture = null;
        $uploadDir = "../uploads/";
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true); // Create the uploads directory if it doesn't exist
        }
        $fileName = uniqid() . "_" . basename($_FILES['profile_picture']['name']);
        $uploadFile = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $uploadFile)) {
            $profilePicture = "uploads/" . $fileName; // Save relative path
        }

        $hashedPassword = password_hash($password, PASSWORD_BCRYPT); // Hash the password

        $sql = "INSERT INTO users (name, email, password, gender, status, profile_picture) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $name, $email, $hashedPassword, $gender, $status, $profilePicture);

        if ($stmt->execute()) {
            // Automatically log in the user after signup
            $_SESSION['user_id'] = $stmt->insert_id; // Set the session with the new user's ID
            header("Location: ../index.php"); // Redirect to index.php
            exit();
        } else {
            $error = "Error signing up: " . $conn->error;
        }

        $stmt->close();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f0ff;
        }

        .container {
            display: flex;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
        }

        .left {
            flex: 1;
            background: #e5e1f7;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
            text-align: center;
        }

        .left img {
            width: 100%;
            max-width: 300px;
            height: auto;
        }

        .left h2 {
            margin-top: 15px;
            color: #6a0dad;
        }

        .right {
            flex: 1;
            padding: 40px;
        }

        .right h2 {
            color: #6a0dad;
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background: #6a0dad;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn:hover {
            background: #570b9c;
        }

        .login-link {
            text-align: center;
            margin-top: 10px;
        }

        .login-link a {
            color: #6a0dad;
            text-decoration: none;
        }

        label.error {
            color: #ff6666; /* Light red color for validation errors */
            font-size: 14px;
            margin-top: 5px;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                box-shadow: none;
                border-radius: 0;
            }
            .left {
                padding: 10px;
            }
            .right {
                padding: 20px;
            }
            .form-group input, .form-group select {
                font-size: 14px;
            }
            .btn {
                font-size: 14px;
            }
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function () {
            $("#signupForm").validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 2
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    password: {
                        required: true,
                        minlength: 6
                    },
                    confirm_password: {
                        required: true,
                        equalTo: "#password"
                    },
                    gender: {
                        required: true
                    },
                    profile_picture: {
                        required: true,
                        extension: "jpg|jpeg|png|gif"
                    }
                },
                messages: {
                    name: {
                        required: "Please enter your full name",
                        minlength: "Your name must be at least 2 characters long"
                    },
                    email: {
                        required: "Please enter your email address",
                        email: "Please enter a valid email address"
                    },
                    password: {
                        required: "Please provide a password",
                        minlength: "Your password must be at least 6 characters long"
                    },
                    confirm_password: {
                        required: "Please confirm your password",
                        equalTo: "Passwords do not match"
                    },
                    gender: {
                        required: "Please select your gender"
                    },
                    profile_picture: {
                        required: "Please upload a profile picture",
                        extension: "Only image files (jpg, jpeg, png, gif) are allowed"
                    }
                },
                errorPlacement: function (error, element) {
                    error.insertAfter(element); // Place error message directly below the input field
                }
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="left">
            <img src="signup.svg" alt="Signup Illustration">
            <h2>Join Our Community</h2>
            <p>Create an account to get started</p>
        </div>
        <div class="right">
            <h2>Create Account</h2>
            <p>Enter your details to sign up</p>

            <form id="signupForm" method="POST" action="" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" id="name" name="name" placeholder="John Doe" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="john@example.com" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <div class="form-group">
                    <label for="confirm-password">Confirm Password</label>
                    <input type="password" id="confirm-password" name="confirm_password" required>
                </div>
                <?php if ($error): ?>
                <p style="color:rgb(244, 56, 56); font-size: 14px;"><?php echo $error; ?></p>
                <?php endif; ?>
                <div class="form-group">
                    <label for="gender">Gender</label>
                    <select id="gender" name="gender" required>
                        <option value="" disabled selected>Select your gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="profile_picture">Choose Profile Picture</label>
                    <input type="file" id="profile_picture" name="profile_picture" accept="image/*" required>
                </div>
                <button type="submit" class="btn">Create Account</button>
            </form>
            <p class="login-link">Already have an account? <a href="signIn.php">Sign in</a></p>
        </div>
    </div>
</body>
</html>
