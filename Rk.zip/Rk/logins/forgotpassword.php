<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f0ff;
        }

        .container {
            display: flex;
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
        }

        .left {
            flex: 1;
            background: #e5e1f7;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            padding: 20px;
            text-align: center;
        }

        .left img {
            width: 100%;
            max-width: 300px;
            height: auto;
        }

        .left h2 {
            margin-top: 15px;
            color: #6a0dad;
        }

        .right {
            flex: 1;
            padding: 40px;
        }

        .right h2 {
            color: #6a0dad;
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background: #6a0dad;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        .btn:hover {
            background: #570b9c;
        }

        .otp-container {
            display: none;
        }

        #errorMessage {
            color: red;
            display: none;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="left">
            <img src="forgotpassword.svg" alt="Forgot Password Illustration">
            <h2>Reset Your Password</h2>
            <p>Enter your email to reset your password</p>
        </div>
        <div class="right">
            <h2>Forgot Password</h2>
            <form id="resetForm">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="john@example.com" required>
                </div>
                <button type="submit" class="btn">Send OTP</button>
            </form>
            <div class="otp-container">
                <h2>Verify OTP</h2>
                <p>Enter the OTP sent to your email.</p>
                <div class="form-group">
                    <input type="text" id="otp" placeholder="Enter OTP" maxlength="6" required>
                </div>
                <button id="verifyOtpBtn" class="btn">Verify OTP</button>
                <p id="errorMessage">Invalid OTP. Please try again.</p>
                <p id="countdownTimer" style="color: #333; margin-top: 10px;"></p>
                <button id="resendOtpBtn" class="btn" style="display: none;">Resend OTP</button>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            let email = '';
            let countdownInterval;

            function startCountdown(duration) {
                let timer = duration, minutes, seconds;
                $('#countdownTimer').show();
                $('#resendOtpBtn').hide();

                countdownInterval = setInterval(function () {
                    minutes = Math.floor(timer / 60);
                    seconds = timer % 60;

                    $('#countdownTimer').text(`Resend OTP in ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`);

                    if (--timer < 0) {
                        clearInterval(countdownInterval);
                        $('#countdownTimer').hide();
                        $('#resendOtpBtn').show();
                    }
                }, 1000);
            }

            $('#resetForm').submit(function (e) {
                e.preventDefault();
                email = $('#email').val().trim();

                $.ajax({
                    url: 'send_otp.php',
                    type: 'POST',
                    data: { email: email },
                    success: function (response) {
                        if (response.success) {
                            alert(response.message);
                            $('#resetForm').hide();
                            $('.otp-container').show();
                            startCountdown(120); // Start 2-minute countdown
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function () {
                        alert("An error occurred. Please try again later.");
                    }
                });
            });

            $('#resendOtpBtn').click(function () {
                $.ajax({
                    url: 'send_otp.php',
                    type: 'POST',
                    data: { email: email },
                    success: function (response) {
                        if (response.success) {
                            alert(response.message);
                            startCountdown(120); // Restart 2-minute countdown
                        } else {
                            alert(response.message);
                        }
                    },
                    error: function () {
                        alert("An error occurred. Please try again later.");
                    }
                });
            });

            $('#verifyOtpBtn').click(function () {
                const otp = $('#otp').val().trim();

                $.ajax({
                    url: 'verify_otp.php',
                    type: 'POST',
                    data: { email: email, otp: otp },
                    success: function (response) {
                        if (response.success) {
                            alert("OTP verified successfully!");
                            window.location.href = 'reset_password.php';
                        } else {
                            $('#errorMessage').show();
                        }
                    },
                    error: function () {
                        alert("An error occurred. Please try again later.");
                    }
                });
            });
        });
    </script>
</body>
</html>
