<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    $isLoggedIn = false;
} else {
    $isLoggedIn = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Navbar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            font-weight: bold;
        }
        .navbar {
            background-color: #3b7e9b !important;
        }
        .navbar-nav {
            margin: center;
        }
        .btn-outline-light {
            margin-left: auto;
        }
        .nav-link.active {
            font-weight: bold;
            color: #fff !important;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="/Rk/index.php">ADMIN PANEL</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'dashboard') ? 'active' : ''; ?>" href="/Rk/dashboard.php">Dashboard</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'users') ? 'active' : ''; ?>" href="/Rk/USERS/user.php">Users</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'booked_events') ? 'active' : ''; ?>" href="/Rk/BOOKED/bookedevents.php">Booked Events</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'contacts') ? 'active' : ''; ?>" href="/Rk/CONTACT/contacts.php">Contacts</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'manage_events') ? 'active' : ''; ?>" href="/Rk/EVENTPLANNER/Eventplanner.php">Events Planner</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'offers') ? 'active' : ''; ?>" href="/Rk/OFFERS/offers.php">Offers</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'about_us') ? 'active' : ''; ?>" href="/Rk/ABOUTUS/about-admin.php">About us</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'venues') ? 'active' : ''; ?>" href="/Rk/VENUES/venues.php">Venues</a></li>
                    <li class="nav-item"><a class="nav-link <?php echo ($current_page == 'gallery') ? 'active' : ''; ?>" href="/Rk/GALLERY/gallery.php">Gallery</a></li>
                </ul>
                <?php if ($isLoggedIn): ?>
                    <a id="auth-button" class="btn btn-outline-light" href="/Rk/logout.php">Logout</a>
                <?php else: ?>
                    <a id="auth-button" class="btn btn-outline-light" href="/Rk/login.php">Login</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
