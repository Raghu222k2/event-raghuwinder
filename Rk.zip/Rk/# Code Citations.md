# Code Citations

## License: GPL_3_0
https://github.com/giuseppelagualano/Restaurant-delivery-website/tree/f26b6eb9e8d719c19ec60525545ea121b955aae2/README.md

```
/ Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
``
```


## License: unknown
https://github.com/yinnitun/demos/tree/bb7264a9aef76cf5ad5a73deb1ceac8992e7c48b/code_challenge_Catalyst_IT/user_upload.php

```
"users_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
```

