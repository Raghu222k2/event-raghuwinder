<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $_SESSION['user_id'] = $_POST['user_id'];
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
?>
