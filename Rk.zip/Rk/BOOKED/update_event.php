<?php
include_once "../db.php";

$id = $_POST['id'];
$name = $_POST['name'];
$status = $_POST['status'];
$img = $_FILES['img']['name'];

if (!empty($img)) {
    $target_dir = "../uploads/";
    $target_file = $target_dir . basename($img);
    move_uploaded_file($_FILES['img']['tmp_name'], $target_file);

    $sql = "UPDATE booked_events SET event_name=?, status=?, img=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $status, $img, $id);
} else {
    $sql = "UPDATE booked_events SET event_name=?, status=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $name, $status, $id);
}

if ($stmt->execute()) {
    echo "Event updated successfully";
} else {
    echo "Error updating event: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
