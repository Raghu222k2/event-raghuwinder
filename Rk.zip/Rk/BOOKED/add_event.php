<?php
include_once "../db.php";

header('Content-Type: application/json');

$name = $_POST['name'] ?? null;
$status = $_POST['status'] ?? null;
$img = $_FILES['img']['name'] ?? null;

if (empty($name) || empty($status) || empty($img)) {
    echo json_encode(['success' => false, 'message' => 'All fields are required.']);
    exit;
}

$target_dir = "../uploads/";
$target_file = $target_dir . basename($img);

if (move_uploaded_file($_FILES['img']['tmp_name'], $target_file)) {
    $sql = "INSERT INTO booked_events (event_name, status, img) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $name, $status, $img);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Event added successfully.']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Error adding event: ' . $conn->error]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Error uploading image.']);
}

$stmt->close();
$conn->close();
?>
