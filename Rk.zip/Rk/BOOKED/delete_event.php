<?php
include_once "../db.php";

$id = $_POST['id'];

$sql = "DELETE FROM booked_events WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "Event deleted successfully";
} else {
    echo "Error deleting event: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
