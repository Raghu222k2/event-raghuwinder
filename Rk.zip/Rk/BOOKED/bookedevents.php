<?php include_once "../navbar.php"; ?>
<?php include_once "../db.php"; ?>
<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php"); // Redirect to login if not logged in or invalid user
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booked Events</title>
    <link rel="stylesheet" href="../style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <style>
        .edit-btn {
            background-color: #4299e1;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 5px;
            cursor: pointer;
        }
        .edit-btn:hover {
            background-color: #3182ce;
        }
    </style>
    <script>
        $(document).ready(function() {
            function fetchEvents() {
                $.ajax({
                    url: 'fetch_events.php',
                    type: 'GET',
                    success: function(response) {
                        $('table tbody').html(response);
                    }
                });
            }

            fetchEvents();

            $('#addEventForm').on('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);
                $.ajax({
                    url: 'add_event.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            fetchEvents();
                            $('#addEventModal').modal('hide');
                            $('#addEventForm')[0].reset();
                        }
                    }
                });
            });

            $(document).on('click', '.edit-btn', function() {
                const row = $(this).closest('tr');
                $('#editEventId').val(row.find('td:eq(0)').text());
                $('#editEventName').val(row.find('td:eq(1)').text());
                $('#editEventStatus').val(row.find('td:eq(4)').text());
                $('#editEventModal').modal('show');
            });

            $('#editEventForm').on('submit', function(e) {
                e.preventDefault();
                const formData = new FormData(this);
                $.ajax({
                    url: 'update_event.php',
                    type: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function() {
                        fetchEvents();
                        $('#editEventModal').modal('hide');
                    }
                });
            });

            $(document).on('click', '.delete-btn', function() {
                const id = $(this).closest('tr').find('td:eq(0)').text();
                if (confirm('Are you sure you want to delete this event?')) {
                    $.ajax({
                        url: 'delete_event.php',
                        type: 'POST',
                        data: { id },
                        success: function() {
                            fetchEvents();
                        }
                    });
                }
            });

            // Add jQuery validation for Add Event Form
            $('#addEventForm').validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 3
                    },
                    img: {
                        required: true,
                        extension: "jpg|jpeg|png|gif"
                    },
                    status: {
                        required: true
                    }
                },
                messages: {
                    name: {
                        required: "Please enter an event name",
                        minlength: "Event name must be at least 3 characters long"
                    },
                    img: {
                        required: "Please upload an image",
                        extension: "Only image files are allowed (jpg, jpeg, png, gif)"
                    },
                    status: {
                        required: "Please select a status"
                    }
                }
            });

            // Add jQuery validation for Edit Event Form
            $('#editEventForm').validate({
                rules: {
                    name: {
                        required: true,
                        minlength: 3
                    },
                    img: {
                        extension: "jpg|jpeg|png|gif"
                    },
                    status: {
                        required: true
                    }
                },
                messages: {
                    name: {
                        required: "Please enter an event name",
                        minlength: "Event name must be at least 3 characters long"
                    },
                    img: {
                        extension: "Only image files are allowed (jpg, jpeg, png, gif)"
                    },
                    status: {
                        required: "Please select a status"
                    }
                }
            });
        });
    </script>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <h1 class="text-center my-4">Booked Events</h1>
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEventModal">Add Event</button>
                </div>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped">
                        <thead class="">
                            <tr>
                                <th>ID</th>
                                <th>Event Name</th>
                                <th>Image</th>
                                <th>Actions</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <!-- Events will be loaded here -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Add Event Modal -->
    <div class="modal fade" id="addEventModal" tabindex="-1" aria-labelledby="addEventModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="addEventForm" novalidate>
                    <div class="modal-header">
                        <h5 class="modal-title" id="addEventModalLabel">Add Event</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="addEventName" class="form-label">Event Name</label>
                            <input type="text" class="form-control" id="addEventName" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventImg" class="form-label">Event Image</label>
                            <input type="file" class="form-control" id="addEventImg" name="img" accept="image/*" required>
                        </div>
                        <div class="mb-3">
                            <label for="addEventStatus" class="form-label">Status</label>
                            <select class="form-control" id="addEventStatus" name="status" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Add Event</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Event Modal -->
    <div class="modal fade" id="editEventModal" tabindex="-1" aria-labelledby="editEventModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <form id="editEventForm" novalidate>
                    <div class="modal-header">
                        <h5 class="modal-title" id="editEventModalLabel">Edit Event</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="editEventId" name="id">
                        <div class="mb-3">
                            <label for="editEventName" class="form-label">Event Name</label>
                            <input type="text" class="form-control" id="editEventName" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="editEventImg" class="form-label">Event Image</label>
                            <input type="file" class="form-control" id="editEventImg" name="img" accept="image/*">
                        </div>
                        <div class="mb-3">
                            <label for="editEventStatus" class="form-label">Status</label>
                            <select class="form-control" id="editEventStatus" name="status" required>
                                <option value="Active">Active</option>
                                <option value="Inactive">Inactive</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>