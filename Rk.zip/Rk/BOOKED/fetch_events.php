<?php
include_once "../db.php";

$sql = "SELECT * FROM booked_events";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['event_name']}</td>
                <td><img src='../uploads/{$row['img']}' alt='Event Image' style='height: 120px; width: 200px;'></td>
                <td>
                    <button class='btn btn-warning edit-btn'>Edit</button>
                    <button class='btn btn-danger delete-btn'>Delete</button>
                </td>
                <td>{$row['status']}</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='5'>No events found</td></tr>";
}

$conn->close();
?>
