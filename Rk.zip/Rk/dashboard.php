<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php"); // Redirect to login if not logged in or invalid user
    exit();
}
?>
<?php include_once "navbar.php"; ?>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f9;
        margin: 0;
        padding: 0;
    }
    .dashboard-container {
        max-width: 1200px;
        margin: 50px auto;
        padding: 20px;
        background: #ffffff;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .dashboard-title {
        font-size: 2.5rem;
        font-weight: bold;
        color: #333;
        text-align: center;
        margin-bottom: 30px;
    }
    .card-container {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
        justify-content: center;
    }
    .card {
        flex: 1 1 calc(33.333% - 20px);
        max-width: calc(33.333% - 20px);
        background: #007bff;
        color: #fff;
        border-radius: 10px;
        padding: 20px;
        text-align: center;
        transition: transform 0.3s ease;
    }
    .card:hover {
        transform: translateY(-5px);
    }
    .card h5 {
        font-size: 1.2rem;
        margin-bottom: 10px;
    }
    .card p {
        font-size: 1.5rem;
        font-weight: bold;
    }
</style>
<body>
    <div class="dashboard-container">
        <h1 class="dashboard-title">Admin Dashboard</h1>
        <div class="card-container">
            <?php
                // Fetch data dynamically
                $sections = [
                    "Users" => "/Rk/user.php",
                    "Booked Events" => "/Rk/BOOKED/bookedevents.php",
                    "Contacts" => "/Rk/CONTACT/contacts.php",
                    "Event Planners" => "/Rk/EVENTPLANNER/Eventplanner.php",
                    "Offers" => "/Rk/OFFERS/offers.php",
                    "Venues" => "/Rk/VENUES/venues.php"
                ];

                function fetchData($url) {
                    // Simulate data for demonstration purposes
                    $mockData = [
                        "/Rk/user.php" => json_encode(["count" => 2]),
                        "/Rk/BOOKED/bookedevents.php" => json_encode(["count" => 5]),
                        "/Rk/CONTACT/contacts.php" => json_encode(["count" => 10]),
                        "/Rk/EVENTPLANNER/Eventplanner.php" => json_encode(["count" => 3]),
                        "/Rk/OFFERS/offers.php" => json_encode(["count" => 7]),
                        "/Rk/VENUES/venues.php" => json_encode(["count" => 4]),
                    ];

                    return isset($mockData[$url]) ? $mockData[$url] : false;
                }

                foreach ($sections as $title => $url) {
                    $data = fetchData($url);
                    $count = 0; // Default to 0 if no data is available
                    if ($data !== false) {
                        $json = json_decode($data, true);
                        $count = isset($json['count']) ? $json['count'] : 0; // Expecting a 'count' key in the JSON response
                    }
                    echo "
                        <div class='card'>
                            <h5>$title</h5>
                            <p>$count</p>
                        </div>
                    ";
                }
            ?>
        </div>
    </div>
</body>
</html>
