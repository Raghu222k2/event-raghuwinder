<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "my_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Database connection failed.', 'error' => $conn->connect_error]));
}

// Enable error reporting for debugging
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Ensure the users table has the required columns
$conn->query("
    ALTER TABLE users 
    ADD COLUMN IF NOT EXISTS otp VARCHAR(6) NULL,
    ADD COLUMN IF NOT EXISTS otp_expiration DATETIME NULL
");

// Ensure the uploads directory exists
$uploadsDir = __DIR__ . '/uploads';
if (!file_exists($uploadsDir)) {
    mkdir($uploadsDir, 0777, true);
}


