<?php
$servername = "localhost";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create database
$sql = "CREATE DATABASE IF NOT EXISTS my_db";
if ($conn->query($sql) === TRUE) {
    echo "Database created successfully";
} else {
    echo "Error creating database: " . $conn->error;
}

// Select the database
$conn->select_db("my_db");

// Create users table
$sql = "CREATE TABLE IF NOT EXISTS users (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    -- age INT(3) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    -- dob DATE NOT NULL,
    status VARCHAR(10) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table users created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Check if 'password' column exists before adding it
$result = $conn->query("SHOW COLUMNS FROM users LIKE 'password'");
if ($result->num_rows === 0) {
    $sql = "ALTER TABLE users ADD COLUMN password VARCHAR(255) NOT NULL AFTER email";
    if ($conn->query($sql) === TRUE) {
        echo "Column password added successfully to users table";
    } else {
        echo "Error adding column password: " . $conn->error;
    }
}

// Check if 'role' column exists before adding it
$result = $conn->query("SHOW COLUMNS FROM users LIKE 'role'");
if ($result->num_rows === 0) {
    $sql = "ALTER TABLE users ADD COLUMN role VARCHAR(20) NOT NULL DEFAULT 'user' AFTER status";
    if ($conn->query($sql) === TRUE) {
        echo "Column role added successfully to users table";
    } else {
        echo "Error adding column role: " . $conn->error;
    }
}

// Check if 'profile_picture' column exists before adding it
$result = $conn->query("SHOW COLUMNS FROM users LIKE 'profile_picture'");
if ($result->num_rows === 0) {
    $sql = "ALTER TABLE users ADD COLUMN profile_picture VARCHAR(255) AFTER role";
    if ($conn->query($sql) === TRUE) {
        echo "Column profile_picture added successfully to users table";
    } else {
        echo "Error adding column profile_picture: " . $conn->error;
    }
}

// Create booked_events table
$sql = "CREATE TABLE IF NOT EXISTS booked_events (
    id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(255) NOT NULL,
    status ENUM('Active', 'Inactive') NOT NULL,
    img VARCHAR(255) DEFAULT 'default.jpg'
)";

if ($conn->query($sql) === TRUE) {
    echo "Table booked_events created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Create event_manager table
$sql = "CREATE TABLE IF NOT EXISTS event_manager (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    experience INT(3) NOT NULL,
    email VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    image VARCHAR(255) NOT NULL,
    -- event_date DATE NOT NULL,
    -- event_location VARCHAR(100) NOT NULL,
    budget INT(10) NOT NULL,
    status VARCHAR(10) NOT NULL
)";

if ($conn->query($sql) === TRUE) {
    echo "Table event_manager created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Create contacts table
$sql = "CREATE TABLE IF NOT EXISTS contacts (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(50) NOT NULL,
    phone VARCHAR(15) NOT NULL,
    inquire TEXT NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status VARCHAR(10) NOT NULL DEFAULT 'Pending'
)";

if ($conn->query($sql) === TRUE) {
    echo "Table contacts created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Check if 'reply_message' column exists before adding it
$result = $conn->query("SHOW COLUMNS FROM contacts LIKE 'reply_message'");
if ($result->num_rows === 0) {
    $sql = "ALTER TABLE contacts ADD COLUMN reply_message TEXT NULL AFTER inquire";
    if ($conn->query($sql) === TRUE) {
        echo "Column reply_message added successfully to contacts table";
    } else {
        echo "Error adding column reply_message: " . $conn->error;
    }
}

// Create gallery table
$sql = "CREATE TABLE IF NOT EXISTS gallery (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    filename VARCHAR(255) NOT NULL,
    filepath VARCHAR(255) NOT NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($sql) === TRUE) {
    echo "Table gallery created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Create venues table
$sql = "CREATE TABLE IF NOT EXISTS venues (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    venue VARCHAR(100) NOT NULL,
    budget VARCHAR(50) NOT NULL,
    capacity VARCHAR(50) NOT NULL,
    sq_ft INT(10) NOT NULL,
    location VARCHAR(255) NOT NULL,
    image VARCHAR(255) DEFAULT 'default.jpg',
    status VARCHAR(10) NOT NULL DEFAULT 'Inactive'
)";

if ($conn->query($sql) === TRUE) {
    echo "Table venues created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Create about_us table
$sql = "CREATE TABLE IF NOT EXISTS about_us (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    hero_title VARCHAR(255) NOT NULL,
    hero_description TEXT NOT NULL,
    story_title VARCHAR(255) NOT NULL,
    story_description TEXT NOT NULL,
    story_image VARCHAR(255) DEFAULT 'default.jpg'
)";

if ($conn->query($sql) === TRUE) {
    echo "Table about_us created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

// Insert default content if table is empty
$result = $conn->query("SELECT COUNT(*) AS count FROM about_us");
$row = $result->fetch_assoc();
if ($row['count'] == 0) {
    $sql = "INSERT INTO about_us (hero_title, hero_description, story_title, story_description, story_image) VALUES (
        'About Our Venue Company',
        'We are passionate about creating unforgettable experiences through exceptional venues and event spaces. With years of expertise, we bring your vision to life in the perfect setting.',
        'Our Story',
        'Founded in 2010, our journey began with a simple vision: to create spaces where memories are made. What started as a single venue has grown into a collection of premium locations across the country. Over the years, we\'ve hosted thousands of events, from intimate gatherings to grand celebrations. Each event has shaped our understanding of what makes a venue truly special. Today, we continue to innovate and expand, always with our core mission in mind: to provide exceptional spaces for life\'s most important moments.',
        'default.jpg'
    )";
    $conn->query($sql);
}

// Create offers table
$sql = "CREATE TABLE IF NOT EXISTS offers (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    discount_percent INT(3) NOT NULL,
    original_price DECIMAL(10, 2) NOT NULL,
    expiry_date DATE NOT NULL,
    tag VARCHAR(50),
    image VARCHAR(255) DEFAULT 'default.jpg',
    code VARCHAR(50) NOT NULL,
    status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active'
)";

if ($conn->query($sql) === TRUE) {
    echo "Table offers created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?>