<?php include "../header.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Special Offers</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f5f7fa;
            /* padding: 40px 20px; */
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .page-title {
            background: linear-gradient(to right, #8b5cf6, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-align: center;
            margin-bottom: 40px;
            /* color: #333; */
            font-size: 2.5rem;
            position: relative;
        }
        
        .page-title:after {
            content: "";
            display: block;
            width: 80px;
            height: 4px;
            background: linear-gradient(90deg, #ff6b6b, #ffa36b);
            margin: 15px auto 0;
            border-radius: 2px;
        }
        
        .offers-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .offer-card {
            background-color: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }
        
        .offer-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .offer-tag {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #ff6b6b;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: bold;
            z-index: 1;
        }
        
        .offer-image {
            height: 200px;
            width: 100%;
            object-fit: cover;
            border-bottom: 4px solid #f5f7fa;
        }
        
        .offer-content {
            padding: 25px;
        }
        
        .offer-title {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 10px;
        }
        
        .offer-description {
            color: #666;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        
        .offer-details {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .offer-price {
            display: flex;
            flex-direction: column;
        }
        
        .discount-percent {
            font-size: 2rem;
            font-weight: bold;
            color: #ff6b6b;
        }
        
        .original-price {
            text-decoration: line-through;
            color: #999;
            font-size: 0.9rem;
        }
        
        .offer-expiry {
            background-color: #f5f7fa;
            padding: 8px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            color: #666;
            display: flex;
            align-items: center;
        }
        
        .offer-expiry i {
            margin-right: 5px;
            color: #ff6b6b;
        }
        
        .offer-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .offer-code {
            background-color: #f5f7fa;
            padding: 10px 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 1rem;
            color: #333;
            letter-spacing: 1px;
            border: 1px dashed #ddd;
        }
        
        .claim-btn {
            background: linear-gradient(90deg, #ff6b6b, #ffa36b);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        
        .claim-btn:hover {
            transform: scale(1.05);
        }
        
        .featured-badge {
            position: absolute;
            top: 0;
            left: 0;
            background: linear-gradient(135deg, #ff6b6b, #ffa36b);
            color: white;
            padding: 8px 15px;
            font-size: 0.8rem;
            font-weight: bold;
            clip-path: polygon(0 0, 100% 0, 85% 100%, 0 100%);
            width: 120px;
        }
        
        /* Responsive Design */
        @media (max-width: 768px) {
            .offers-grid {
                grid-template-columns: 1fr;
            }
            
            .page-title {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="page-title">Special Offers & Discounts</h1>
        
        <div class="offers-grid">
            <?php
            include '../db.php';
            $offers = $conn->query("SELECT * FROM offers WHERE status='Active'")->fetch_all(MYSQLI_ASSOC);
            foreach ($offers as $offer):
            ?>
            <div class="offer-card">
                <?php if ($offer['tag']): ?>
                <span class="offer-tag"><?= $offer['tag'] ?></span>
                <?php endif; ?>
                <img src="../uploads/<?= $offer['image'] ?>" alt="<?= $offer['title'] ?>" class="offer-image">
                <div class="offer-content">
                    <h2 class="offer-title"><?= $offer['title'] ?></h2>
                    <p class="offer-description"><?= $offer['description'] ?></p>
                    <div class="offer-details">
                        <div class="offer-price">
                            <span class="discount-percent"><?= $offer['discount_percent'] ?>% OFF</span>
                            <span class="original-price">Original: ₹<?= $offer['original_price'] ?></span>
                        </div>
                        <div class="offer-expiry">
                            <i>⏱</i> Expires on: <?= $offer['expiry_date'] ?>
                        </div>
                    </div>
                    <div class="offer-actions">
                        <span class="offer-code"><?= $offer['code'] ?></span>
                        <button class="claim-btn">Claim Offer</button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</body>
</html>