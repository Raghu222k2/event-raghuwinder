<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php");
    exit();
}

include '../db.php';
include "../navbar.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'] ?? null;
    $title = $_POST['title'];
    $description = $_POST['description'];
    $discount_percent = $_POST['discount_percent'];
    $original_price = $_POST['original_price'];
    $expiry_date = $_POST['expiry_date'];
    $tag = $_POST['tag'];
    $code = $_POST['code'];
    $status = $_POST['status'];
    $image = $_FILES['image']['name'] ?? null;

    if ($image) {
        $target = $uploadsDir . '/' . basename($image);
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
    }

    if ($id) {
        // Update existing offer
        $sql = "UPDATE offers SET 
                title='$title', description='$description', discount_percent=$discount_percent, 
                original_price=$original_price, expiry_date='$expiry_date', tag='$tag', 
                code='$code', status='$status'" . ($image ? ", image='$image'" : "") . " 
                WHERE id=$id";
    } else {
        // Insert new offer
        $sql = "INSERT INTO offers (title, description, discount_percent, original_price, expiry_date, tag, code, status, image) 
                VALUES ('$title', '$description', $discount_percent, $original_price, '$expiry_date', '$tag', '$code', '$status', '$image')";
    }

    $conn->query($sql);
    header('Location: offers.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM offers WHERE id=$id");
    header('Location: offers.php');
    exit;
}

$offers = $conn->query("SELECT * FROM offers")->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Manage Offers</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f7fa;
            margin: 0;
            /* padding: 20px; */
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 0 auto 30px;
        }

        form label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
            color: #555;
        }

        form input, form textarea, form select, form button {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 1rem;
        }

        form button {
            background: #4299e1;
            color: white;
            font-weight: bold;
            cursor: pointer;
            border: none;
            transition: background 0.3s ease;
        }
/* 
        form button:hover {
            background: linear-gradient(90deg, #ffa36b, #ff6b6b);
        } */

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        table th, table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #f5f7fa;
            color: #333;
            font-weight: bold;
        }

        table tr:hover {
            background-color: #f9f9f9;
        }

        table a {
            color: #ff6b6b;
            text-decoration: none;
            font-weight: bold;
        }

        table a:hover {
            text-decoration: underline;
        }

        .actions a {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <h1>Manage Offers</h1>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" id="id">
        <label>Title: <input type="text" name="title" id="title" required></label>
        <label>Description: <textarea name="description" id="description" required></textarea></label>
        <label>Discount Percent: <input type="number" name="discount_percent" id="discount_percent" required></label>
        <label>Original Price: <input type="number" step="0.01" name="original_price" id="original_price" required></label>
        <label>Expiry Date: <input type="date" name="expiry_date" id="expiry_date" required></label>
        <label>Tag: <input type="text" name="tag" id="tag"></label>
        <label>Code: <input type="text" name="code" id="code" required></label>
        <label>Status: 
            <select name="status" id="status">
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
            </select>
        </label>
        <label>Image: <input type="file" name="image" id="image"></label>
        <button type="submit">Save Offer</button>
    </form>

    <h2>Existing Offers</h2>
    <table>
        <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Discount</th>
            <th>Price</th>
            <th>Expiry</th>
            <th>Tag</th>
            <th>Code</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($offers as $offer): ?>
        <tr>
            <td><?= $offer['title'] ?></td>
            <td><?= $offer['description'] ?></td>
            <td><?= $offer['discount_percent'] ?>%</td>
            <td>₹<?= $offer['original_price'] ?></td>
            <td><?= $offer['expiry_date'] ?></td>
            <td><?= $offer['tag'] ?></td>
            <td><?= $offer['code'] ?></td>
            <td><?= $offer['status'] ?></td>
            <td class="actions">
                <a href="javascript:void(0)" onclick="editOffer(<?= htmlspecialchars(json_encode($offer)) ?>)">Edit</a>
                <a href="?delete=<?= $offer['id'] ?>" onclick="return confirm('Are you sure?')">Delete</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <script>
        function editOffer(offer) {
            document.getElementById('id').value = offer.id;
            document.getElementById('title').value = offer.title;
            document.getElementById('description').value = offer.description;
            document.getElementById('discount_percent').value = offer.discount_percent;
            document.getElementById('original_price').value = offer.original_price;
            document.getElementById('expiry_date').value = offer.expiry_date;
            document.getElementById('tag').value = offer.tag;
            document.getElementById('code').value = offer.code;
            document.getElementById('status').value = offer.status;
        }
    </script>
</body>
</html>
<?php
ob_end_flush(); // End output buffering and flush the output
?>
