<?php include "../header.php"; ?>
<?php include "../db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }
        
        .contact-header {
            text-align: center;
            padding: 60px 0 40px;
            background: linear-gradient(to right, #8b5cf6, #ec4899);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        
        .contact-header h1 {
            font-size: 2.5rem;
            margin-bottom: 15px;
            /* color: #2d3748; */
        }
        
        .contact-header p {
            font-size: 1.1rem;
            color: #718096;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .contact-wrapper {
            display: flex;
            flex-wrap: wrap;
            background: white;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            margin-bottom: 60px;
        }
        
        .contact-info {
            flex: 1;
            min-width: 300px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            padding: 40px;
        }
        
        .contact-info h3 {
            font-size: 1.5rem;
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 10px;
        }
        
        .contact-info h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: rgba(255, 255, 255, 0.5);
        }
        
        .info-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 25px;
        }
        
        .info-icon {
            width: 30px;
            height: 30px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 1rem;
        }
        
        .info-details {
            flex: 1;
        }
        
        .info-details h4 {
            font-size: 1rem;
            margin-bottom: 5px;
            opacity: 0.9;
        }
        
        .info-details p {
            font-size: 0.95rem;
            opacity: 0.8;
        }
        
        .contact-form {
            flex: 2;
            min-width: 300px;
            padding: 40px;
        }
        
        .contact-form h3 {
            font-size: 1.5rem;
            margin-bottom: 25px;
            color: #2d3748;
            position: relative;
            padding-bottom: 10px;
        }
        
        .contact-form h3::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 50px;
            height: 3px;
            background: #667eea;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #4a5568;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            border-radius: 6px;
            font-size: 1rem;
            transition: border-color 0.3s ease;
        }
        
        .form-control:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        
        textarea.form-control {
            min-height: 120px;
            resize: vertical;
        }
        
        .submit-btn {
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .error {
            color: red !important; /* Ensure the color is red */
            font-size: 0.9rem;
            margin-top: 5px;
        }
    </style>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#contactForm').validate({
                rules: {
                    fullName: {
                        required: true,
                        minlength: 3
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    phone: {
                        required: true,
                        digits: true,
                        minlength: 10,
                        maxlength: 15
                    },
                    message: {
                        required: true,
                        minlength: 10
                    }
                },
                messages: {
                    fullName: {
                        required: "Please enter your full name",
                        minlength: "Your name must be at least 3 characters long"
                    },
                    email: {
                        required: "Please enter your email address",
                        email: "Please enter a valid email address"
                    },
                    phone: {
                        required: "Please enter your phone number",
                        digits: "Please enter only digits",
                        minlength: "Your phone number must be at least 10 digits long",
                        maxlength: "Your phone number must not exceed 15 digits"
                    },
                    message: {
                        required: "Please enter your message",
                        minlength: "Your message must be at least 10 characters long"
                    }
                },
                errorPlacement: function(error, element) {
                    error.insertAfter(element);
                }
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="contact-header">
            <h1>Get in Touch</h1>
            <p>Have questions about our venues or services? We're here to help! Fill out the form below and our team will get back to you as soon as possible.</p>
        </div>
        
        <div class="contact-wrapper">
            <div class="contact-info">
                <h3>Contact Information</h3>
                
                <div class="info-item">
                    <div class="info-icon">📍</div>
                    <div class="info-details">
                        <h4>Our Location</h4>
                        <p>RKU CAMPUS, RAJKOT City, 151505</p>
                    </div>
                </div>
                
                <div class="info-item">
                    <div class="info-icon">📞</div>
                    <div class="info-details">
                        <h4>Phone Number</h4>
                        <p>+91 8699602410</p>
                    </div>
                </div>
                
                <div class="info-item">
                    <div class="info-icon">✉️</div>
                    <div class="info-details">
                        <h4>Email Address</h4>
                        <p>Raghuwinderkumar24k@gmail.com</p>
                    </div>
                </div>
                
                <div class="info-item">
                    <div class="info-icon">⏰</div>
                    <div class="info-details">
                        <h4>Working Hours</h4>
                        <p>Mon - Fri: 9:00 AM - 6:00 PM</p>
                    </div>
                </div>
            </div>
            
            <div class="contact-form">
                <h3>Send us a Message</h3>
                
                <?php
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $fullName = $conn->real_escape_string($_POST['fullName']);
                    $email = $conn->real_escape_string($_POST['email']);
                    $phone = $conn->real_escape_string($_POST['phone']);
                    $message = $conn->real_escape_string($_POST['message']);

                    $sql = "INSERT INTO contacts (name, email, phone, inquire) VALUES ('$fullName', '$email', '$phone', '$message')";
                    if ($conn->query($sql) === TRUE) {
                        echo "<p style='color: green;'>Message sent successfully!</p>";
                    } else {
                        echo "<p style='color: red;'>Error: " . $conn->error . "</p>";
                    }
                }
                ?>

                <form id="contactForm" method="POST" action="">
                    <div class="form-group">
                        <label for="fullName">Full Name</label>
                        <input type="text" id="fullName" name="fullName" class="form-control" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone</label>
                            <input type="tel" id="phone" name="phone" class="form-control">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" class="form-control" required></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn">Send Message</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>