<?php
include "../db.php";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $conn->real_escape_string($_POST['id']);
    $replyMessage = $conn->real_escape_string($_POST['replyMessage']);
    $email = $conn->real_escape_string($_POST['email']);

    // Update the status and save the reply message in the database
    $sql = "UPDATE contacts SET status = 'Replied', reply_message = '$replyMessage' WHERE id = '$id'";
    if ($conn->query($sql) === TRUE) {
        // Send the reply to the user's email
        $subject = "Reply to Your Inquiry";
        $headers = "From: admin@yourdomain.com\r\n";
        $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
        mail($email, $subject, $replyMessage, $headers);

        echo "Reply sent successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
