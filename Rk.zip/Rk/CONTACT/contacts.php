<?php
session_start();
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] !== 'Raghu') {
    header("Location: /Rk/login.php"); // Redirect to login if not logged in or invalid user
    exit();
}
?>
<?php include_once "../navbar.php"; ?>
<?php include_once "../db.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inquiries Lists</title>
    <link rel="stylesheet" href="../style.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#replyForm').validate({
                rules: {
                    replyMessage: {
                        required: true,
                        minlength: 2
                    }
                },
                messages: {
                    replyMessage: {
                        required: "Please enter a reply message",
                        minlength: "Reply message must be at least 2 characters long"
                    }
                },
                submitHandler: function(form) {
                    const replyMessage = $('#replyMessage').val().trim();
                    const row = $('#replyModal').data('row');
                    const id = row.data('id');
                    const email = row.find('td:eq(2)').text();

                    $.ajax({
                        url: 'reply_contact.php',
                        type: 'POST',
                        data: { id: id, replyMessage: replyMessage, email: email },
                        success: function(response) {
                            row.find('.status').removeClass('status-inactive').addClass('status-active').text('Replied');
                            $('#replyModal').modal('hide');
                        }
                    });
                }
            });

            $(document).on('click', '.reply-btn', function() {
                const row = $(this).closest('tr');
                const userName = row.find('td:eq(1)').text();
                const userEmail = row.find('td:eq(2)').text();
                const userInquire = row.find('td:eq(4)').text();

                $('#replyUserName').text(userName);
                $('#replyUserEmail').text(userEmail);
                $('#replyUserInquire').text(userInquire);

                $('#replyModal').data('row', row).modal('show');
            });

            $(document).on('click', '.delete-btn', function() {
                const row = $(this).closest('tr');
                const id = row.data('id');

                $.ajax({
                    url: 'delete_contact.php',
                    type: 'POST',
                    data: { id: id },
                    success: function(response) {
                        row.remove();
                        updateSerialNumbers();
                    }
                });
            });

            function updateSerialNumbers() {
                $('table tbody tr').each(function(index) {
                    $(this).find('td:eq(0)').text(index + 1);
                });
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1 class="title">INQUIRIES LISTS</h1>
        </div>
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>S.No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone No</th>
                        <th>Inquire</th>
                        <th>Actions</th>
                        <th>Status</th>
                        <th>Reply Message</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sql = "SELECT * FROM contacts";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $serialNumber = 1;
                        while($row = $result->fetch_assoc()) {
                            echo "<tr data-id='{$row['id']}'>
                                    <td>{$serialNumber}</td>
                                    <td>{$row['name']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['phone']}</td>
                                    <td class='inqurie-text'>{$row['inquire']}</td>
                                    <td>
                                        <button class='action-btn reply-btn'>Reply</button>
                                        <button class='action-btn delete-btn'>Delete</button>
                                    </td>
                                    <td><span class='status status-".($row['status'] == 'Replied' ? 'active' : 'inactive')."'>{$row['status']}</span></td>
                                    <td>" . (!empty($row['reply_message']) ? $row['reply_message'] : 'No reply yet') . "</td>
                                </tr>";
                            $serialNumber++;
                        }
                    } else {
                        echo "<tr><td colspan='8'>No inquiries found</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Reply Modal -->
    <div class="modal fade" id="replyModal" tabindex="-1" aria-labelledby="replyModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="replyModalLabel">Reply to Inquiry</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="replyForm">
                        <div class="mb-3">
                            <label for="replyUserName" class="form-label">Name</label>
                            <p id="replyUserName"></p>
                        </div>
                        <div class="mb-3">
                            <label for="replyUserEmail" class="form-label">Email</label>
                            <p id="replyUserEmail"></p>
                        </div>
                        <div class="mb-3">
                            <label for="replyUserInquire" class="form-label">Inquire</label>
                            <p id="replyUserInquire"></p>
                        </div>
                        <div class="mb-3">
                            <label for="replyMessage" class="form-label">Reply Message</label>
                            <textarea class="form-control" id="replyMessage" rows="3" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>